const DEFAULT = {
  whatsapp: "9647731236452",
  pin: "2468",
  services: [
    {id:"hour", name:"الساعة الواحدة", description:"جلسة مساج مهني واسترخاء لمدة ساعة", price:50000},
    {id:"night", name:"ليلة كاملة", description:"باقة مسائية ممتدة حسب تفاصيل الحجز", price:150000}
  ],
  members: []
};
const KEY = "alshaikha_catalog_v1";
let data = loadData();
let photoData = "";
const $ = id => document.getElementById(id);
function loadData(){
  try { const saved = JSON.parse(localStorage.getItem(KEY)); return saved ? {...DEFAULT,...saved} : structuredClone(DEFAULT); }
  catch { return structuredClone(DEFAULT); }
}
function saveData(){ localStorage.setItem(KEY, JSON.stringify(data)); render(); }
function money(n){ return new Intl.NumberFormat("en-US").format(Number(n)||0) + " د.ع"; }
function waLink(message){
  const number = String(data.whatsapp || DEFAULT.whatsapp).replace(/\D/g,"");
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}
function toast(msg){ $("toast").textContent=msg; $("toast").classList.add("show"); setTimeout(()=>$("toast").classList.remove("show"),2400); }
function render(){
  $("serviceGrid").innerHTML = data.services.map(s=>`<article class="service-card"><div><h3>${esc(s.name)}</h3><p>${esc(s.description||"")}</p></div><div class="price">${money(s.price)}</div></article>`).join("");
  $("teamGrid").innerHTML = data.members.map(m=>`<article class="member-card">${m.photo?`<img class="member-photo" src="${m.photo}" alt="${esc(m.name)}">`:`<div class="member-placeholder">✦</div>`}<div class="member-info"><h3>${esc(m.name)}</h3><p>${esc(m.specialty||"عضو الكادر")}</p><a class="gold-btn" href="${waLink("مرحباً، أرغب بالاستفسار عن الحجز مع: "+m.name)}" target="_blank" rel="noopener">التواصل للحجز</a></div></article>`).join("");
  $("emptyTeam").hidden = data.members.length>0;
  $("teamCount").textContent = data.members.length ? `${data.members.length} أعضاء` : "لم تتم إضافة أعضاء بعد";
  $("mainWhatsapp").href = waLink("مرحباً، أود الاستفسار عن خدمات الشيخة.");
  renderAdmin();
}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function renderAdmin(){
  if(!$("adminMembers")) return;
  $("adminMembers").innerHTML = data.members.map(m=>`<div class="admin-row"><div class="admin-avatar">${m.photo?`<img src="${m.photo}" alt="">`:"✦"}</div><div class="row-copy"><strong>${esc(m.name)}</strong><small>${esc(m.specialty||"بدون تخصص")}</small></div><button class="outline-btn" onclick="editMember('${m.id}')">تعديل</button><button class="outline-btn" onclick="deleteMember('${m.id}')">حذف</button></div>`).join("") || `<p class="muted">لا يوجد أعضاء. أضف أول عضو من النموذج أعلاه.</p>`;
  $("adminServices").innerHTML = data.services.map((s,i)=>`<div class="admin-row service-admin"><div class="row-copy"><strong>${esc(s.name)}</strong><small>${esc(s.description||"")}</small></div><label>السعر<input type="number" min="0" step="1000" value="${Number(s.price)||0}" data-price-index="${i}" style="width:145px"></label><button class="outline-btn" onclick="saveService(${i})">حفظ</button></div>`).join("");
}
window.editMember = id => {
  const m=data.members.find(x=>x.id===id); if(!m)return;
  $("memberId").value=m.id; $("memberName").value=m.name; $("memberSpecialty").value=m.specialty||""; $("memberBio").value=m.bio||""; photoData=m.photo||"";
  $("photoPreview").innerHTML=photoData?`<img src="${photoData}" alt="معاينة">`:"معاينة الصورة";
  $("memberForm").scrollIntoView({behavior:"smooth",block:"start"});
};
window.deleteMember = id => { if(confirm("هل تريد حذف هذا العضو من الكتالوج؟")){data.members=data.members.filter(x=>x.id!==id);saveData();toast("تم حذف العضو");}};
window.saveService = i => {
  const input=document.querySelector(`[data-price-index="${i}"]`);
  if(!input || Number(input.value)<0)return;
  data.services[i].price=Number(input.value);saveData();toast("تم تحديث السعر");
};
$("adminOpen").addEventListener("click",()=>{$("adminDialog").showModal();});
function closeAdmin(){$("adminDialog").close();}
$("closeAdmin").onclick=closeAdmin;$("closeAdmin2").onclick=closeAdmin;
$("loginBtn").onclick=()=>{
  if($("adminPin").value===data.pin){$("loginView").hidden=true;$("adminView").hidden=false;$("loginError").textContent="";renderAdmin();}
  else $("loginError").textContent="رمز الإدارة غير صحيح.";
};
$("adminPin").addEventListener("keydown",e=>{if(e.key==="Enter")$("loginBtn").click();});
$("logoutBtn").onclick=()=>{$("adminView").hidden=true;$("loginView").hidden=false;$("adminPin").value="";};
$("memberPhoto").addEventListener("change",e=>{
  const file=e.target.files[0]; if(!file)return;
  if(file.size>5*1024*1024){toast("حجم الصورة أكبر من 5 ميغابايت");e.target.value="";return;}
  const reader=new FileReader();
  reader.onload=()=>{const img=new Image();img.onload=()=>{
    const canvas=document.createElement("canvas");const max=1000;const scale=Math.min(1,max/Math.max(img.width,img.height));canvas.width=Math.round(img.width*scale);canvas.height=Math.round(img.height*scale);
    canvas.getContext("2d").drawImage(img,0,0,canvas.width,canvas.height);photoData=canvas.toDataURL("image/jpeg",.78);$("photoPreview").innerHTML=`<img src="${photoData}" alt="معاينة">`;
  };img.src=reader.result;};reader.readAsDataURL(file);
});
$("memberForm").addEventListener("submit",e=>{
  e.preventDefault();
  const id=$("memberId").value || crypto.randomUUID();
  const old=data.members.find(m=>m.id===id);
  const member={id,name:$("memberName").value.trim(),specialty:$("memberSpecialty").value.trim(),bio:$("memberBio").value.trim(),photo:photoData||old?.photo||""};
  if(!member.name){toast("يرجى إدخال الاسم");return;}
  const index=data.members.findIndex(m=>m.id===id);
  if(index>=0)data.members[index]=member;else data.members.push(member);
  saveData();resetMember();toast("تم حفظ بيانات العضو");
});
function resetMember(){ $("memberForm").reset();$("memberId").value="";photoData="";$("photoPreview").textContent="معاينة الصورة"; }
$("resetMember").onclick=resetMember;
document.querySelectorAll(".tab").forEach(btn=>btn.onclick=()=>{
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b===btn));
  ["members","services","settings"].forEach(t=>$("pane-"+t).hidden=btn.dataset.tab!==t);
});
$("settingsForm").addEventListener("submit",e=>{
  e.preventDefault();
  const num=$("whatsappNumber").value.replace(/\D/g,"");
  if(!/^9647\d{9}$/.test(num)){toast("أدخل الرقم بصيغة عراقية دولية مثل 9647xxxxxxxxx");return;}
  data.whatsapp=num;
  const pin=$("newPin").value.trim();
  if(pin){if(pin.length<4){toast("رمز الإدارة يجب أن يكون 4 خانات على الأقل");return;}data.pin=pin;}
  saveData();$("newPin").value="";toast("تم حفظ الإعدادات");
});
$("exportData").onclick=()=>{
  const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="alshaikha-backup.json";a.click();URL.revokeObjectURL(a.href);
};
$("importData").addEventListener("change",e=>{
  const f=e.target.files[0];if(!f)return;
  const r=new FileReader();r.onload=()=>{try{const imported=JSON.parse(r.result);if(!Array.isArray(imported.members)||!Array.isArray(imported.services))throw Error();data={...DEFAULT,...imported};saveData();toast("تم استيراد النسخة الاحتياطية");}catch{toast("ملف النسخة الاحتياطية غير صالح");}};r.readAsText(f);e.target.value="";
});
if("serviceWorker" in navigator && location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
render();
