-- AL SHEIKHA starter schema. Review and tighten RLS policies before production.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  role text not null default 'client' check (role in ('admin','client')),
  created_at timestamptz not null default now()
);

create table if not exists public.staff (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  age integer,
  address text,
  has_place boolean not null default false,
  activity_status text not null default 'available' check (activity_status in ('available','busy','unavailable')),
  hourly_price_iqd bigint not null default 0,
  overnight_price_iqd bigint not null default 0,
  bio text,
  photo_paths text[] not null default '{}',
  is_visible boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.sessions (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  session_date timestamptz not null,
  staff_id uuid references public.staff(id) on delete set null,
  notes text,
  photo_paths text[] not null default '{}',
  created_at timestamptz not null default now()
);

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  customer_id uuid references public.profiles(id) on delete set null,
  staff_id uuid references public.staff(id) on delete set null,
  starts_at timestamptz not null,
  ends_at timestamptz,
  status text not null default 'pending' check (status in ('pending','confirmed','completed','cancelled')),
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.banners (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  image_path text not null,
  staff_id uuid references public.staff(id) on delete set null,
  session_id uuid references public.sessions(id) on delete set null,
  sort_order integer not null default 0,
  is_active boolean not null default true
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references public.profiles(id) on delete cascade,
  customer_name text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid references public.profiles(id) on delete set null,
  body text not null default '',
  attachment_path text,
  created_at timestamptz not null default now()
);

create table if not exists public.favorites (
  customer_id uuid not null references public.profiles(id) on delete cascade,
  staff_id uuid not null references public.staff(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(customer_id, staff_id)
);

-- Enable RLS. Add production policies after defining verified admin membership.
alter table public.profiles enable row level security;
alter table public.staff enable row level security;
alter table public.sessions enable row level security;
alter table public.bookings enable row level security;
alter table public.banners enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.favorites enable row level security;

-- Safe public read for published catalogue content. Admin writes must be added
-- through a trusted backend / carefully tested role policies.
create policy "public can read visible staff" on public.staff
for select using (is_visible = true);
create policy "public can read active banners" on public.banners
for select using (is_active = true);
