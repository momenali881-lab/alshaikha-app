# AL SHEIKHA — Flutter monorepo

مستودع واحد يحتوي تطبيق الإدارة وتطبيق العملاء، مع إعداد أولي لـ Supabase وGitHub Actions.

## المتطلبات
- Flutter stable (القناة المستقرة)
- Android SDK
- حساب Supabase عند تفعيل المزامنة السحابية

## تشغيل التطبيقين محلياً
```bash
cd admin_app
flutter pub get
flutter run
```
وفي نافذة أخرى:
```bash
cd client_app
flutter pub get
flutter run
```

## إعداد Supabase
1. أنشئ مشروعاً جديداً في Supabase.
2. افتح SQL Editor وشغّل `supabase/schema.sql`.
3. انسخ `.env.example` إلى `.env` في التطبيق الذي تريد تشغيله، ثم أدخل Project URL وAnon Key.
4. شغّل التطبيق بتمرير القيم:
```bash
flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY
```
لا تضع `service_role` key داخل تطبيق Android مطلقاً. يجب تنفيذ صلاحيات الإدارة الحساسة عبر خادم موثوق وسياسات RLS.

## البناء
يمكن البناء محلياً:
```bash
flutter build apk --release
```
ملفات GitHub Actions في `.github/workflows/` تبني APK لكل تطبيق عند تشغيل workflow يدوياً أو عند push.

## بنية المشروع
- `admin_app/`: تطبيق إدارة مستقل.
- `client_app/`: تطبيق العميل مستقل.
- `supabase/schema.sql`: مخطط قاعدة البيانات الأولي.
- `.github/workflows/`: بناء APK تلقائي.

## تنبيه نطاق النسخة
هذه نقطة انطلاق عملية قابلة للبناء والتوسعة، وليست نظام إنتاج مكتملًا بعد. واجهات الكادر والحجوزات والدردشة والأرشيف موجودة كبداية UI؛ يلزم استكمال الشاشات التفصيلية، المصادقة، رفع الصور، قواعد الصلاحيات، والإشعارات واختبارها قبل الإطلاق العام.
