import 'package:flutter/material.dart';

const ink = Color(0xFF292730);
const plum = Color(0xFF80616A);
const rose = Color(0xFFD9B9B8);
const cream = Color(0xFFF7F1EF);
const gold = Color(0xFFD6BC91);

ThemeData buildTheme({bool dark = false}) {
  final scheme = ColorScheme.fromSeed(
    seedColor: plum,
    brightness: dark ? Brightness.dark : Brightness.light,
    surface: dark ? const Color(0xFF302D35) : cream,
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: dark ? ink : cream,
    appBarTheme: const AppBarTheme(centerTitle: false, elevation: 0),
    cardTheme: CardThemeData(
      color: dark ? const Color(0xFF39343D) : Colors.white.withValues(alpha: .78),
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: dark ? const Color(0xFF302D35) : Colors.white,
      indicatorColor: rose.withValues(alpha: .45),
    ),
  );
}
