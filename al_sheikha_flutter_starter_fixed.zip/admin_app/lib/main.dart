import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'theme.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
  runApp(const SheikhaApp());
}

class SheikhaApp extends StatefulWidget {
  const SheikhaApp({super.key});
  @override
  State<SheikhaApp> createState() => _SheikhaAppState();
}

class _SheikhaAppState extends State<SheikhaApp> {
  bool dark = false;
  int tab = 0;
  final pages = const [DashboardPage(), StaffPage(), BookingsPage(), ChatPage(), SettingsPage()];
  final labels = const ['الرئيسية','الكادر','الحجوزات','الدردشة','الإعدادات'];
  final icons = const [Icons.grid_view_rounded,Icons.groups_rounded,Icons.calendar_month_rounded,Icons.chat_bubble_outline_rounded,Icons.settings_rounded];

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'AL SHEIKHA',
    theme: buildTheme(dark: dark),
    home: Scaffold(
      appBar: AppBar(
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('الشيخة', style: TextStyle(fontWeight: FontWeight.w800)),
          Text('AL SHEIKHA MASSAGE CENTER', style: TextStyle(fontSize: 9, letterSpacing: 1.2)),
        ]),
        actions: [
          IconButton(tooltip: 'تبديل المظهر', onPressed: () => setState(() => dark = !dark),
            icon: Icon(dark ? Icons.light_mode_rounded : Icons.dark_mode_rounded)),
          const SizedBox(width: 8),
        ],
      ),
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: List.generate(5, (i) => NavigationDestination(icon: Icon(icons[i]), label: labels[i])),
      ),
    ),
  );
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: const LinearGradient(colors: [Color(0xFF80616A),Color(0xFFB99498)]),
      ),
      child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('أهلاً بك في الشيخة', style: TextStyle(color: Colors.white70)),
        SizedBox(height: 8),
        Text('تجربة راقية، وإدارة أسهل', style: TextStyle(color: Colors.white,fontSize: 23,fontWeight: FontWeight.bold)),
        SizedBox(height: 18),
        Text('لوحة التحكم الرئيسية', style: TextStyle(color: Colors.white)),
      ]),
    ),
    const SizedBox(height: 18),
    const Text('نظرة عامة', style: TextStyle(fontSize: 19,fontWeight: FontWeight.bold)),
    const SizedBox(height: 10),
    const Wrap(spacing: 10,runSpacing: 10,children: [
      MetricTile(label:'أعضاء الكادر',value:'—',icon:Icons.groups_rounded),
      MetricTile(label:'حجوزات اليوم',value:'—',icon:Icons.event_available_rounded),
      MetricTile(label:'المحادثات',value:'—',icon:Icons.forum_rounded),
      MetricTile(label:'الجلسات المؤرشفة',value:'—',icon:Icons.photo_library_rounded),
    ]),
    const SizedBox(height: 20),
    const Text('الوصول السريع',style: TextStyle(fontSize: 19,fontWeight: FontWeight.bold)),
    const SizedBox(height: 10),
    const FeatureRow(icon:Icons.person_add_alt_1_rounded,title:'إضافة عضو للكادر',subtitle:'إدارة الملف والصور والأسعار'),
    const FeatureRow(icon:Icons.add_photo_alternate_outlined,title:'أرشيف الجلسات',subtitle:'حفظ الصور وربطها بالتاريخ والعضو'),
    const FeatureRow(icon:Icons.campaign_outlined,title:'إدارة البنرات',subtitle:'حتى 7 بنرات في الواجهة'),
  ]);
}

class MetricTile extends StatelessWidget {
  final String label,value; final IconData icon;
  const MetricTile({super.key,required this.label,required this.value,required this.icon});
  @override Widget build(BuildContext context) => SizedBox(width: MediaQuery.sizeOf(context).width/2-24,
    child: Card(child: Padding(padding: const EdgeInsets.all(15),child: Column(crossAxisAlignment: CrossAxisAlignment.start,children:[
      Icon(icon,color: Theme.of(context).colorScheme.primary,size:25),const SizedBox(height:12),
      Text(value,style: const TextStyle(fontSize:23,fontWeight: FontWeight.bold)),
      Text(label,style: Theme.of(context).textTheme.bodySmall),
    ]))));
}

class FeatureRow extends StatelessWidget {
  final IconData icon; final String title,subtitle;
  const FeatureRow({super.key,required this.icon,required this.title,required this.subtitle});
  @override Widget build(BuildContext context) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: rose.withValues(alpha:.35),child: Icon(icon,color: plum)),title: Text(title),subtitle: Text(subtitle),trailing: const Icon(Icons.chevron_left_rounded)));
}

class StaffPage extends StatelessWidget {
  const StaffPage({super.key});
  @override Widget build(BuildContext context) => const EmptySection(icon:Icons.groups_rounded,title:'إدارة الكادر',description:'ستظهر هنا ملفات الأعضاء، حتى 10 صور لكل عضو، العمر والعنوان والتوفر والأسعار بالدينار العراقي.',action:'إضافة عضو');
}
class BookingsPage extends StatelessWidget {
  const BookingsPage({super.key});
  @override Widget build(BuildContext context) => const EmptySection(icon:Icons.calendar_month_rounded,title:'الحجوزات',description:'إدارة العضو والتاريخ والوقت واسم العميل وحالة الحجز.',action:'إنشاء حجز');
}
class ChatPage extends StatelessWidget {
  const ChatPage({super.key});
  @override Widget build(BuildContext context) => const EmptySection(icon:Icons.forum_rounded,title:'محادثات العملاء',description:'محادثة خاصة لكل عميل، مع إمكانية مشاركة ملف العضو وتسجيل الحجز من المحادثة.',action:'المحادثات');
}
class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override Widget build(BuildContext context) => const EmptySection(icon:Icons.tune_rounded,title:'الإعدادات',description:'المظهر، الإشعارات، الحساب والصلاحيات.',action:'الإعدادات');
}
class EmptySection extends StatelessWidget {
  final IconData icon; final String title,description,action;
  const EmptySection({super.key,required this.icon,required this.title,required this.description,required this.action});
  @override Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(26),child: Column(mainAxisAlignment: MainAxisAlignment.center,children:[
    CircleAvatar(radius:38,backgroundColor: rose.withValues(alpha:.3),child: Icon(icon,size:34,color:plum)),
    const SizedBox(height:18),Text(title,style: const TextStyle(fontSize:23,fontWeight:FontWeight.bold)),
    const SizedBox(height:8),Text(description,textAlign:TextAlign.center,style: Theme.of(context).textTheme.bodyMedium),
    const SizedBox(height:20),FilledButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('سيتم تفعيل هذه الوظيفة ضمن مراحل التطوير التالية'))),child:Text(action)),
  ])));
}
