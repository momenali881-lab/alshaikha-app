package com.alshaikha.app

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri

class SharedDataProvider : ContentProvider() {
    override fun onCreate(): Boolean = true
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val key = uri.lastPathSegment ?: ""
        val value = context?.getSharedPreferences("alshaikha_shared", 0)?.getString(key, null)
        return MatrixCursor(arrayOf("key", "value")).apply {
            if (value != null) addRow(arrayOf(key, value))
        }
    }
    override fun getType(uri: Uri): String = "vnd.android.cursor.item/vnd.alshaikha.shared"
    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        val key = values?.getAsString("key") ?: return null
        val value = values.getAsString("value") ?: ""
        context?.getSharedPreferences("alshaikha_shared", 0)?.edit()?.putString(key, value)?.apply()
        return Uri.withAppendedPath(uri, key)
    }
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int {
        val key = uri.lastPathSegment ?: return 0
        context?.getSharedPreferences("alshaikha_shared", 0)?.edit()?.remove(key)?.apply()
        return 1
    }
    override fun update(uri: Uri, values: ContentValues?, selection: String?,
        selectionArgs: Array<out String>?): Int = if (insert(uri, values) != null) 1 else 0
}
