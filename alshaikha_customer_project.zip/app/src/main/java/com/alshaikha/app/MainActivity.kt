package com.alshaikha.app

import android.annotation.SuppressLint
import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private val adminAuthority = "com.alsheikha.app.admin.shared"
    private val ownAuthority = BuildConfig.APPLICATION_ID + ".shared"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AppBridge(), "AndroidBridge")
        webView.loadUrl("file:///android_asset/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("window.handleAndroidBack && window.handleAndroidBack()", null)
            }
        })
    }

    inner class AppBridge {
        private fun dataUri(key: String): Uri {
            val authority = if (BuildConfig.APP_ROLE == "admin") ownAuthority else adminAuthority
            return Uri.parse("content://$authority/data/${Uri.encode(key)}")
        }
        @JavascriptInterface fun getRole(): String = BuildConfig.APP_ROLE
        @JavascriptInterface fun hasSharedStore(): Boolean {
            return try { packageManager.resolveContentProvider(adminAuthority, 0) != null || BuildConfig.APP_ROLE == "admin" } catch (_: Exception) { false }
        }
        @JavascriptInterface fun getShared(key: String): String? {
            return try {
                val c = contentResolver.query(dataUri(key), arrayOf("key","value"), null, null, null)
                c?.use { if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow("value")) else null }
            } catch (_: Exception) { null }
        }
        @JavascriptInterface fun setShared(key: String, value: String) {
            try {
                val cv = ContentValues().apply { put("key", key); put("value", value) }
                contentResolver.insert(dataUri(key), cv)
            } catch (_: Exception) { }
        }
        @JavascriptInterface fun removeShared(key: String) {
            try { contentResolver.delete(dataUri(key), null, null) } catch (_: Exception) { }
        }
        @JavascriptInterface fun toast(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message.take(120), Toast.LENGTH_SHORT).show() }
        }
    }
}
