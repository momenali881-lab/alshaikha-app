const DEFAULT = { whatsapp: "9647731236452", pin: "2468", members: [] };
const KEY = "alshaikha_catalog_v2";
let data = loadData();
let photoData = [];
const $ = id => document.getElementById(id);
function loadData(){
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || "null");
    if (saved) return {...DEFAULT, ...saved, members:(saved.members||[]).map(m=>({...m, photos:Array.isArray(m.photos)?m.photos:(m.photo?[m.photo]:[]), services:Array.isArray(m.services)?m.services:[]}))};
    const old = JSON.parse(localStorage.getItem("alshaikha_catalog_v1") || "null");
    if (old) return {...DEFAULT, whatsapp:old.whatsapp||DEFAULT.whatsapp, pin:old.pin||DEFAULT.pin, members:(old.members||[]).map(m=>({...m,photos:m.photo?[m.photo]:[],services:[]}))};
    return structuredClone(DEFAULT);
  } catch { return structuredClone(DEFAULT); }
}
function saveData(){ localStorage.setItem(KEY, JSON.stringify(data)); render(); }
function money(n){return new Intl.NumberFormat("en-US").format(Number(n)||0)+" د.ع";}
function waLink(message){const n=String(data.whatsapp||DEFAULT.whatsapp).replace(/\D/g,"");return `https://wa.me/${n}?text=${encodeURIComponent(message)}`;}
function toast(msg){$("toast").textContent=msg;$("toast").classList.add("show");setTimeout(()=>$ ("toast").classList.remove("show"),2400);}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function render(){
  $("teamGrid").innerHTML=data.members.map(m=>{
    const photos=m.photos||[]; const first=photos[0]||"";
    return `<article class="member-card"><button class="member-open" type="button" onclick="showMember('${m.id}')">${first?`<img class="member-photo" src="${first}" alt="${esc(m.name)}">`:`<div class="member-placeholder">✦</div>`}<div class="member-info"><h3>${esc(m.name)}</h3><p>${esc(m.specialty||"خدمات مساج مهني")}</p><span class="gold-btn">عرض التفاصيل والأسعار</span></div></button></article>`;
  }).join("");
  $("emptyTeam").hidden=data.members.length>0;
  $("teamCount").textContent=data.members.length?`${data.members.length} أعضاء`:"لم تتم إضافة أعضاء بعد";
  $("mainWhatsapp").href=waLink("مرحباً، أود الاستفسار عن خدمات الشيخة.");
  renderAdmin();
}
function renderAdmin(){
  if(!$("adminMembers"))return;
  $("adminMembers").innerHTML=data.members.map(m=>`<div class="admin-row"><div class="admin-avatar">${m.photos?.[0]?`<img src="${m.photos[0]}" alt="">`:"✦"}</div><div class="row-copy"><strong>${esc(m.name)}</strong><small>${(m.services||[]).length} خدمات · ${(m.photos||[]).length} صور</small></div><button class="outline-btn" onclick="editMember('${m.id}')">تعديل</button><button class="outline-btn" onclick="deleteMember('${m.id}')">حذف</button></div>`).join("")||`<p class="muted">لا يوجد أعضاء. أضف أول عضو من النموذج.</p>`;
}
window.showMember=id=>{
  const m=data.members.find(x=>x.id===id);if(!m)return;
  const gallery=(m.photos||[]).map(p=>`<img src="${p}" alt="${esc(m.name)}">`).join("");
  const services=(m.services||[]).map(s=>`<div class="detail-service"><div><strong>${esc(s.name)}</strong><small>${esc(s.duration||"")}</small></div><b>${money(s.price)}</b></div>`).join("")||`<p class="muted">لا توجد خدمات وأسعار مضافة لهذا العضو حالياً.</p>`;
  $("detailContent").innerHTML=`<div class="detail-gallery">${gallery||"<div class='member-placeholder'>✦</div>"}</div><h2>${esc(m.name)}</h2><p>${esc(m.specialty||"")}</p><p>${esc(m.bio||"")}</p><h3>الخدمات والأسعار الخاصة بهذا العضو</h3><div class="detail-services">${services}</div><a class="gold-btn full" href="${waLink("مرحباً، أود الاستفسار عن الحجز مع "+m.name+". يرجى تأكيد الخدمة والسعر.")}" target="_blank" rel="noopener">الاستفسار عبر واتساب</a>`;
  $("memberDetails").showModal();
};
window.editMember=id=>{
  const m=data.members.find(x=>x.id===id);if(!m)return;
  $("memberId").value=m.id;$("memberName").value=m.name;$("memberSpecialty").value=m.specialty||"";$("memberBio").value=m.bio||"";
  photoData=[...(m.photos||[])];
  $("memberServices").value=(m.services||[]).map(s=>`${s.name} | ${s.duration||""} | ${s.price||0}`).join("\n");
  renderPhotoPreview();$("memberForm").scrollIntoView({behavior:"smooth",block:"start"});
};
window.deleteMember=id=>{if(confirm("هل تريد حذف هذا العضو؟")){data.members=data.members.filter(x=>x.id!==id);saveData();toast("تم حذف العضو");}};
function renderPhotoPreview(){ $("photoPreview").innerHTML=photoData.length?photoData.map((p,i)=>`<div class="preview-item"><img src="${p}" alt="صورة ${i+1}"><button type="button" onclick="removePhoto(${i})">×</button></div>`).join(""):`<span>معاينة الصور</span>`; }
window.removePhoto=i=>{photoData.splice(i,1);renderPhotoPreview();};
function closeAdmin(){$("adminDialog").close();}
$("adminOpen").addEventListener("click",()=>$("adminDialog").showModal());
$("closeAdmin").onclick=closeAdmin;$("closeAdmin2").onclick=closeAdmin;
$("loginBtn").onclick=()=>{if($("adminPin").value===data.pin){$("loginView").hidden=true;$("adminView").hidden=false;$("loginError").textContent="";renderAdmin();}else $("loginError").textContent="رمز الإدارة غير صحيح.";};
$("adminPin").addEventListener("keydown",e=>{if(e.key==="Enter")$("loginBtn").click();});
$("logoutBtn").onclick=()=>{$("adminView").hidden=true;$("loginView").hidden=false;$("adminPin").value="";};
async function compressImage(file){
  if(!file.type.startsWith("image/"))throw Error("ليس ملف صورة");
  return new Promise((resolve,reject)=>{const r=new FileReader();r.onerror=reject;r.onload=()=>{const img=new Image();img.onerror=reject;img.onload=()=>{const max=700,scale=Math.min(1,max/Math.max(img.width,img.height));const c=document.createElement("canvas");c.width=Math.round(img.width*scale);c.height=Math.round(img.height*scale);c.getContext("2d").drawImage(img,0,0,c.width,c.height);resolve(c.toDataURL("image/jpeg",.68));};img.src=r.result;};r.readAsDataURL(file);});
}
$("memberPhoto").addEventListener("change",async e=>{
  const files=[...e.target.files];if(!files.length)return;
  if(photoData.length+files.length>5){toast("الحد الأقصى 5 صور للعضو");e.target.value="";return;}
  try{for(const f of files){if(f.size>8*1024*1024)throw Error("حجم الصورة أكبر من 8 ميغابايت");photoData.push(await compressImage(f));}renderPhotoPreview();}
  catch(err){toast(err.message||"تعذر قراءة الصورة");}
  e.target.value="";
});
$("memberForm").addEventListener("submit",e=>{
  e.preventDefault();const id=$("memberId").value||crypto.randomUUID();
  const services=$("memberServices").value.split("\n").map(line=>line.trim()).filter(Boolean).map(line=>{const a=line.split("|").map(x=>x.trim());return {name:a[0]||"خدمة",duration:a[1]||"",price:Number(a[2])||0};}).filter(s=>s.name&&s.price>=0);
  const member={id,name:$("memberName").value.trim(),specialty:$("memberSpecialty").value.trim(),bio:$("memberBio").value.trim(),photos:photoData,services};
  if(!member.name){toast("يرجى إدخال الاسم");return;}
  const i=data.members.findIndex(m=>m.id===id);if(i>=0)data.members[i]=member;else data.members.push(member);
  saveData();resetMember();toast("تم حفظ بيانات العضو");
});
function resetMember(){$("memberForm").reset();$("memberId").value="";photoData=[];renderPhotoPreview();}
$("resetMember").onclick=resetMember;
$("settingsForm").addEventListener("submit",e=>{e.preventDefault();const n=$("whatsappNumber").value.replace(/\D/g,"");if(!/^9647\d{9}$/.test(n)){toast("أدخل الرقم بصيغة دولية مثل 9647xxxxxxxxx");return;}data.whatsapp=n;const pin=$("newPin").value.trim();if(pin){if(pin.length<4){toast("رمز الإدارة يجب أن يكون 4 خانات على الأقل");return;}data.pin=pin;}saveData();$("newPin").value="";toast("تم حفظ الإعدادات");});
$("exportData").onclick=()=>{const b=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="alshaikha-backup.json";a.click();URL.revokeObjectURL(a.href);};
$("importData").addEventListener("change",e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);if(!Array.isArray(x.members))throw Error();data={...DEFAULT,...x};data.members=data.members.map(m=>({...m,photos:m.photos||(m.photo?[m.photo]:[]),services:m.services||[]}));saveData();toast("تم استيراد النسخة الاحتياطية");}catch{toast("ملف النسخة الاحتياطية غير صالح");}};r.readAsText(f);e.target.value="";});
if("serviceWorker" in navigator&&location.protocol.startsWith("http"))navigator.serviceWorker.register("./sw.js").catch(()=>{});
render();renderPhotoPreview();
