package com.alshaikha.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import org.json.JSONArray;
import org.json.JSONObject;

public class CatalogProvider extends ContentProvider {
    private static final String PREFS="shared_catalog";
    private static final String KEY="catalog_json";
    private boolean allowed(){ String p=getCallingPackage(); return p==null || p.equals("com.alshaikha.client") || p.equals("com.alshaikha.admin"); }
    @Override public boolean onCreate(){ return true; }
    @Override public Bundle call(String method,String arg,Bundle extras){
        if(!allowed()) throw new SecurityException("Caller not allowed");
        android.content.SharedPreferences sp=getContext().getSharedPreferences(PREFS,0);
        String raw=sp.getString(KEY,"{\"pin\":\"2468\",\"members\":[],\"proofs\":[],\"messages\":[]}");
        Bundle out=new Bundle();
        if("getCatalog".equals(method)){out.putString("catalog",raw);return out;}
        if("saveCatalog".equals(method)){String v=extras==null?null:extras.getString("catalog");if(v!=null){sp.edit().putString(KEY,v).apply();out.putBoolean("ok",true);}return out;}
        if("appendBooking".equals(method)){try{JSONObject obj=new JSONObject(raw);JSONArray arr=obj.optJSONArray("bookings");if(arr==null)arr=new JSONArray();JSONObject booking=new JSONObject(extras.getString("booking","{}"));arr.put(booking);obj.put("bookings",arr);sp.edit().putString(KEY,obj.toString()).apply();out.putBoolean("ok",true);}catch(Exception e){out.putBoolean("ok",false);}return out;}
        if("appendMessage".equals(method)){try{JSONObject obj=new JSONObject(raw);JSONArray msgs=obj.optJSONArray("messages");if(msgs==null)msgs=new JSONArray();JSONObject msg=new JSONObject();msg.put("from","user");msg.put("text",extras.getString("text",""));msg.put("time",System.currentTimeMillis());msgs.put(msg);obj.put("messages",msgs);sp.edit().putString(KEY,obj.toString()).apply();out.putBoolean("ok",true);}catch(Exception e){out.putBoolean("ok",false);}return out;}
        return out;
    }
    @Override public Cursor query(Uri u,String[] p,String s,String[] a,String o){return null;}
    @Override public String getType(Uri u){return "application/json";}
    @Override public Uri insert(Uri u,ContentValues v){return null;}
    @Override public int delete(Uri u,String s,String[] a){return 0;}
    @Override public int update(Uri u,ContentValues v,String s,String[] a){return 0;}
}
