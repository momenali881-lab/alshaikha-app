plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.alshaikha.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.alsheikha.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    flavorDimensions += "edition"
    productFlavors {
        create("customer") {
            dimension = "edition"
            applicationIdSuffix = ".customer"
            versionNameSuffix = "-customer"
            buildConfigField("String", "APP_ROLE", "\"customer\"")
            resValue("string", "app_name", "الشيخة - العميل")
        }
        create("admin") {
            dimension = "edition"
            applicationIdSuffix = ".admin"
            versionNameSuffix = "-admin"
            buildConfigField("String", "APP_ROLE", "\"admin\"")
            resValue("string", "app_name", "الشيخة - الإدارة")
        }
    }

    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
}
