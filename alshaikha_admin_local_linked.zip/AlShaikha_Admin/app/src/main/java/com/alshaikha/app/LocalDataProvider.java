package com.alshaikha.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class LocalDataProvider extends ContentProvider {
    public static final String AUTHORITY = "com.alshaikha.admin.localdata";
    private File dataFile;
    @Override public boolean onCreate() { dataFile = new File(getContext().getFilesDir(), "shared_catalog.json"); return true; }
    private boolean allowed(String caller) {
        if (caller == null) return false;
        if (!caller.equals("com.alshaikha.admin") && !caller.equals("com.alshaikha.client")) return false;
        return getContext().getPackageManager().checkSignatures(getContext().getPackageName(), caller) == android.content.pm.PackageManager.SIGNATURE_MATCH;
    }
    @Override public Bundle call(String method, String arg, Bundle extras) {
        String caller = getCallingPackage();
        if (!allowed(caller)) throw new SecurityException("Caller not allowed");
        Bundle out = new Bundle();
        try {
            if ("read".equals(method)) {
                out.putString("data", dataFile.exists() ? new String(Files.readAllBytes(dataFile.toPath()), StandardCharsets.UTF_8) : "");
            } else if ("write".equals(method)) {
                String value = extras == null ? null : extras.getString("data");
                if (value == null || value.length() > 25_000_000) throw new IllegalArgumentException("Invalid data");
                File tmp = new File(dataFile.getParentFile(), "shared_catalog.tmp");
                Files.write(tmp.toPath(), value.getBytes(StandardCharsets.UTF_8));
                if (dataFile.exists() && !dataFile.delete()) throw new IllegalStateException("Cannot replace data");
                if (!tmp.renameTo(dataFile)) throw new IllegalStateException("Cannot save data");
                out.putBoolean("ok", true);
            }
        } catch (Exception e) { throw new RuntimeException(e); }
        return out;
    }
    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { throw new UnsupportedOperationException(); }
    @Override public int delete(Uri u, String s, String[] a) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { throw new UnsupportedOperationException(); }
}
