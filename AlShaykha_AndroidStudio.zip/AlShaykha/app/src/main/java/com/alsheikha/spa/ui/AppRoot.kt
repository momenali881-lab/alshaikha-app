package com.alsheikha.spa.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.alsheikha.spa.data.AppVM
import com.alsheikha.spa.data.Config
import com.alsheikha.spa.data.Repo

private data class Tab(val route: String, val label: String, val icon: ImageVector)

@Composable
fun AppRoot(vm: AppVM = viewModel()) {
    val nav = rememberNavController()
    val isAdmin by vm.isAdmin.collectAsState()
    val route = nav.currentBackStackEntryAsState().value?.destination?.route
    val tabs = buildList {
        add(Tab("home", "الرئيسية", Icons.Default.Home))
        add(Tab("bookings", "حجوزاتي", Icons.Default.DateRange))
        if (isAdmin) add(Tab("admin", "الإدارة", Icons.Default.Settings)) else add(Tab("chat", "الدردشة", Icons.Default.Email))
        add(Tab("profile", "حسابي", Icons.Default.Person))
    }
    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val showBar = route in tabs.map { it.route } && !imeOpen

    // عند خروج المدير من تبويب الإدارة نعود للرئيسية
    LaunchedEffect(isAdmin) {
        if (!isAdmin && route == "admin") nav.navigate("home") { popUpTo("home") { inclusive = true } }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBar) NavigationBar {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route,
                        onClick = { nav.navigate(t.route) { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true } },
                        icon = { Icon(t.icon, null) }, label = { Text(t.label) },
                        colors = NavigationBarItemDefaults.colors(indicatorColor = Gold.copy(alpha = .35f))
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, "splash", Modifier.padding(pad)) {
            composable("splash") { SplashScreen { nav.navigate("home") { popUpTo("splash") { inclusive = true } } } }
            composable("home") { HomeScreen(vm) { nav.navigate("staff/$it") } }
            composable("bookings") { BookingsScreen(vm) }
            composable("chat") {
                ChatScreen(Repo.UID, false, "الدردشة مع ${Config.CENTER_NAME}", "تواصل مباشر مع المالكة", null) { nav.navigate("staff/$it") }
            }
            composable("profile") { ProfileScreen(vm) }
            composable("admin") { AdminScreen(vm, onEdit = { nav.navigate("staffedit/$it") }, onChat = { nav.navigate("adminchat") }) }
            composable("staff/{id}") { e ->
                val id = e.arguments?.getString("id") ?: ""
                StaffDetailScreen(
                    vm, id, onBack = { nav.popBackStack() }, onBook = { nav.navigate("book/$id") },
                    onEdit = { nav.navigate("staffedit/$id") },
                    onSent = { nav.navigate("chat") { popUpTo("home"); launchSingleTop = true } }
                )
            }
            composable("book/{id}") { e ->
                BookingScreen(vm, e.arguments?.getString("id") ?: "", { nav.popBackStack() }) {
                    nav.navigate("bookings") { popUpTo("home") }
                }
            }
            composable("staffedit/{id}") { e -> StaffEditorScreen(vm, e.arguments?.getString("id") ?: "new") { nav.popBackStack() } }
            composable("adminchat") {
                ChatScreen(Repo.UID, true, "محادثة العميل", "الرد على العميل", { nav.popBackStack() }) { nav.navigate("staff/$it") }
            }
        }
    }
}
