package com.alsheikha.spa.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn

@OptIn(ExperimentalCoroutinesApi::class)
class AppVM : ViewModel() {
    val isAdmin: StateFlow<Boolean> = Repo.isAdmin.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    /** null = جاري التحميل */
    val staff: StateFlow<List<Staff>?> = Repo.staff().stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val myBookings: StateFlow<List<Booking>> =
        Repo.myBookings(Repo.UID).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val allBookings: StateFlow<List<Booking>> = isAdmin
        .flatMapLatest { a -> if (a) Repo.allBookings() else flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val chats: StateFlow<List<ChatSummary>> = isAdmin
        .flatMapLatest { a -> if (a) Repo.chats() else flowOf(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
}
