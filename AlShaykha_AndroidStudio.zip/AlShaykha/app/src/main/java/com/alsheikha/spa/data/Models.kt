package com.alsheikha.spa.data

data class Staff(
    val id: String = "",
    val name: String = "",
    val age: Int = 0,
    val bio: String = "",
    val specialties: List<String> = emptyList(),
    val photos: List<String> = emptyList(),
    val pricePerHour: Long = 0,
    val priceNight: Long = 0,
    val available: Boolean = true,
    val createdAt: Long = 0
)

data class Booking(
    val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val phone: String = "",
    val staffId: String = "",
    val staffName: String = "",
    val type: String = "HOURLY", // HOURLY | NIGHT
    val hours: Int = 1,
    val date: String = "",
    val startTime: String = "",
    val total: Long = 0,
    val status: String = "PENDING", // PENDING | CONFIRMED | CANCELLED
    val notes: String = "",
    val createdAt: Long = 0
)

data class Message(
    val id: String = "",
    val senderId: String = "",
    val fromAdmin: Boolean = false,
    val text: String = "",
    val staffId: String = "",
    val staffName: String = "",
    val staffPhoto: String = "",
    val time: Long = 0
)

data class ChatSummary(
    val userId: String = "",
    val userName: String = "",
    val lastMessage: String = "",
    val lastTime: Long = 0,
    val unreadAdmin: Long = 0
)
