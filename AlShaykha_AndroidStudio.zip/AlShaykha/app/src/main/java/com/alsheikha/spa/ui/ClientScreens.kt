@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)

package com.alsheikha.spa.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.alsheikha.spa.R
import com.alsheikha.spa.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.Date
import java.util.Locale
import java.util.TimeZone

// ---------------------------------------------------------------- Splash
@Composable
fun SplashScreen(onDone: () -> Unit) {
    var go by remember { mutableStateOf(false) }
    val a by animateFloatAsState(if (go) 1f else 0f, tween(900), label = "a")
    LaunchedEffect(Unit) { go = true; delay(1700); onDone() }
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Plum, PlumDark))).alpha(a),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(painterResource(R.drawable.ic_lotus), null, Modifier.size(130.dp))
        Text(Config.CENTER_NAME, color = GoldLight, fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
        Text("مركز الراحة والاسترخاء", color = Color.White.copy(alpha = .8f), fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        CircularProgressIndicator(color = Gold, modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
    }
}

// ---------------------------------------------------------------- Home
@Composable
fun HomeScreen(vm: AppVM, onStaff: (String) -> Unit) {
    val staff by vm.staff.collectAsState()
    var query by remember { mutableStateOf("") }
    var onlyAvailable by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(Brush.verticalGradient(listOf(Plum, PlumDark))).statusBarsPadding().padding(16.dp)
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.ic_lotus), null, Modifier.size(44.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(Config.CENTER_NAME, color = GoldLight, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                        Text("مركز الراحة والاسترخاء", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                    }
                    ThemeToggle()
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    query, { query = it }, Modifier.fillMaxWidth(),
                    placeholder = { Text("ابحث عن اسم أو تخصص…") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true, shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                        focusedTextColor = Color.Black, unfocusedTextColor = Color.Black,
                        focusedBorderColor = Gold, unfocusedBorderColor = Color.Transparent, cursorColor = Plum,
                        focusedPlaceholderColor = Color.Gray, unfocusedPlaceholderColor = Color.Gray,
                        focusedLeadingIconColor = Plum, unfocusedLeadingIconColor = Plum
                    )
                )
            }
        }
        val list = staff
        if (list == null) LoadingBox() else {
            val filtered = list.filter {
                (!onlyAvailable || it.available) &&
                    (query.isBlank() || it.name.contains(query, true) || it.specialties.any { s -> s.contains(query, true) })
            }
            LazyVerticalGrid(
                GridCells.Fixed(2), Modifier.weight(1f), contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) { PromoBanner() }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        SectionTitle("خدماتنا")
                        Spacer(Modifier.height(10.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(listOf("💆" to "مساج استرخاء", "🔥" to "أحجار ساخنة", "🌿" to "أروماثيرابي",
                                "💪" to "مساج رياضي", "🦶" to "تدليك القدمين", "🧖" to "سبا ومغربي")) { (e, t) ->
                                Column(
                                    Modifier.width(96.dp).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surface)
                                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp)).padding(12.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) { Text(e, fontSize = 28.sp); Text(t, fontSize = 12.sp, textAlign = TextAlign.Center) }
                            }
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf("🔒" to "خصوصية تامة", "✨" to "تعقيم كامل", "⚡" to "حجز سريع").forEach { (e, t) ->
                            Column(
                                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) { Text(e, fontSize = 22.sp); Text(t, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer) }
                        }
                    }
                }
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SectionTitle("كادر العمل", Modifier.weight(1f))
                        FilterChip(onlyAvailable, { onlyAvailable = !onlyAvailable }, { Text("المتاحة فقط") })
                    }
                }
                if (filtered.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyState("🌸", "لا توجد نتائج مطابقة") }
                items(filtered, key = { it.id }) { StaffCard(it) { onStaff(it.id) } }
            }
        }
    }
}

@Composable
private fun PromoBanner() {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(Plum, Color(0xFF6B3B86)))).padding(20.dp)
    ) {
        Column {
            Text("احجزي وقتك بالطريقة التي تناسبك", color = GoldLight, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            Spacer(Modifier.height(6.dp))
            Text("☀️ حجز بالساعة   |   🌙 ليلة كاملة", color = Color.White, fontSize = 14.sp)
            Text("جميع الأسعار بالدينار العراقي", color = Color.White.copy(alpha = .75f), fontSize = 12.sp)
        }
    }
}

// ---------------------------------------------------------------- Staff detail
@Composable
fun StaffDetailScreen(
    vm: AppVM, id: String, onBack: () -> Unit, onBook: () -> Unit, onEdit: () -> Unit, onSent: () -> Unit
) {
    val all by vm.staff.collectAsState()
    val isAdmin by vm.isAdmin.collectAsState()
    val s = all?.find { it.id == id }
    if (s == null) { LoadingBox(); return }
    val scope = rememberCoroutineScope()
    val photos = s.photos
    val pager = rememberPagerState { maxOf(photos.size, 1) }
    var viewer by remember { mutableStateOf<Int?>(null) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Box {
                HorizontalPager(pager, Modifier.fillMaxWidth().aspectRatio(.85f)) { i ->
                    if (photos.isEmpty()) Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Person, null, Modifier.size(90.dp), tint = Gold)
                    } else AsyncImage(photos[i], s.name, Modifier.fillMaxSize().clickable { viewer = i }, contentScale = ContentScale.Crop)
                }
                IconButton(onBack, Modifier.statusBarsPadding().padding(8.dp).background(Color.Black.copy(alpha = .45f), CircleShape)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                }
                if (photos.size > 1) Row(Modifier.align(Alignment.BottomCenter).padding(12.dp), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    repeat(photos.size) { i ->
                        Box(Modifier.size(if (i == pager.currentPage) 10.dp else 7.dp).clip(CircleShape).background(if (i == pager.currentPage) Gold else Color.White.copy(alpha = .7f)))
                    }
                }
            }
            if (photos.size > 1) LazyRow(Modifier.padding(top = 10.dp), contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(photos.size) { i ->
                    AsyncImage(photos[i], null, Modifier.size(64.dp).clip(RoundedCornerShape(12.dp))
                        .border(if (i == pager.currentPage) 2.dp else 0.dp, Gold, RoundedCornerShape(12.dp))
                        .clickable { scope.launch { pager.animateScrollToPage(i) } }, contentScale = ContentScale.Crop)
                }
            }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(s.name + if (s.age > 0) "، ${s.age} سنة" else "", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    AssistChip({}, { Text(if (s.available) "متاحة" else "غير متاحة") })
                }
                if (s.specialties.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    s.specialties.forEach { SuggestionChip({}, { Text(it) }) }
                }
                if (s.bio.isNotBlank()) Text(s.bio, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 24.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    PriceBox("☀️ بالساعة", s.pricePerHour.iqd(), Modifier.weight(1f))
                    PriceBox("🌙 ليلة كاملة", s.priceNight.iqd(), Modifier.weight(1f))
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).navigationBarsPadding().padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (isAdmin) GoldButton("تعديل الملف", Modifier.fillMaxWidth(), icon = Icons.Default.Edit) { onEdit() }
            else {
                OutlineGoldButton("أرسل الملف للشيخة", Modifier.weight(1f), Icons.Default.Email) {
                    scope.launch {
                        Repo.send(Repo.UID, Prefs.userName, Message(
                            senderId = Repo.UID, fromAdmin = false, text = "أرغب بحجز هذا الملف",
                            staffId = s.id, staffName = s.name, staffPhoto = s.photos.firstOrNull() ?: ""
                        ))
                        onSent()
                    }
                }
                GoldButton("احجز الآن", Modifier.weight(1f), enabled = s.available, icon = Icons.Default.DateRange) { onBook() }
            }
        }
    }

    viewer?.let { start ->
        Dialog({ viewer = null }, DialogProperties(usePlatformDefaultWidth = false)) {
            val vp = rememberPagerState(start) { photos.size }
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                HorizontalPager(vp, Modifier.fillMaxSize()) { i ->
                    AsyncImage(photos[i], null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
                IconButton({ viewer = null }, Modifier.align(Alignment.TopStart).statusBarsPadding().padding(8.dp)) {
                    Icon(Icons.Default.Close, null, tint = Color.White)
                }
                Text("${vp.currentPage + 1} / ${photos.size}", color = Color.White, modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp))
            }
        }
    }
}

@Composable
private fun PriceBox(label: String, price: String, modifier: Modifier) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
        Text(price, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

// ---------------------------------------------------------------- Booking
@Composable
fun BookingScreen(vm: AppVM, id: String, onBack: () -> Unit, onDone: () -> Unit) {
    val all by vm.staff.collectAsState()
    val s = all?.find { it.id == id }
    if (s == null) { LoadingBox(); return }
    val scope = rememberCoroutineScope()
    var night by remember { mutableStateOf(false) }
    var hours by remember { mutableIntStateOf(1) }
    var dateMillis by remember { mutableStateOf<Long?>(null) }
    var time by remember { mutableStateOf<String?>(null) }
    var name by remember { mutableStateOf(Prefs.userName) }
    var phone by remember { mutableStateOf(Prefs.phone) }
    var notes by remember { mutableStateOf("") }
    var showDate by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val total = if (night) s.priceNight else s.pricePerHour * hours
    val slots = if (night) (20..23).map { fmtHour(it) } else (10..23).map { fmtHour(it) }
    val dateText = dateMillis?.let {
        SimpleDateFormat("EEEE d MMMM yyyy", Locale("ar")).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(it))
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("حجز موعد", "مع ${s.name}", onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            SectionTitle("نوع الحجز")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TypeCard(!night, "☀️", "بالساعة", s.pricePerHour.iqd() + " / ساعة", Modifier.weight(1f)) { night = false; time = null }
                TypeCard(night, "🌙", "ليلة كاملة", s.priceNight.iqd(), Modifier.weight(1f)) { night = true; time = null }
            }
            if (!night) {
                SectionTitle("عدد الساعات")
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    FilledTonalIconButton({ if (hours > 1) hours-- }) { Text("−", fontSize = 22.sp) }
                    Text("$hours ${if (hours == 1) "ساعة" else "ساعات"}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    FilledTonalIconButton({ if (hours < 8) hours++ }) { Text("+", fontSize = 22.sp) }
                }
            } else Text("الليلة الكاملة تنتهي الساعة 8:00 صباحاً", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)

            SectionTitle("التاريخ")
            OutlineGoldButton(dateText ?: "اختر التاريخ", Modifier.fillMaxWidth(), Icons.Default.DateRange) { showDate = true }

            SectionTitle(if (night) "وقت بداية الليلة" else "وقت البداية")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                slots.forEach { t -> FilterChip(time == t, { time = t }, { Text(t) }) }
            }

            SectionTitle("بياناتك")
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("الاسم") }, singleLine = true, shape = RoundedCornerShape(14.dp))
            OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() } }, Modifier.fillMaxWidth(), label = { Text("رقم الهاتف") },
                singleLine = true, shape = RoundedCornerShape(14.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
            OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth(), label = { Text("ملاحظات (اختياري)") }, shape = RoundedCornerShape(14.dp), minLines = 2)

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("ملخص الحجز", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text(if (night) "🌙 ليلة كاملة" else "☀️ $hours ساعة", color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("الإجمالي: ${total.iqd()}", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            error?.let { Text(it, color = Color(0xFFD64545)) }
        }
        Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).navigationBarsPadding().padding(12.dp)) {
            GoldButton(if (saving) "جاري الإرسال…" else "تأكيد الحجز", Modifier.fillMaxWidth(), enabled = !saving) {
                when {
                    dateMillis == null -> error = "اختر التاريخ"
                    time == null -> error = "اختر وقت البداية"
                    name.isBlank() -> error = "أدخل الاسم"
                    phone.length < 10 -> error = "أدخل رقم هاتف صحيح"
                    else -> scope.launch {
                        saving = true
                        Prefs.saveUser(name.trim(), phone)
                        Repo.createBooking(Booking(
                            userId = Repo.UID, userName = name.trim(), phone = phone, staffId = s.id, staffName = s.name,
                            type = if (night) "NIGHT" else "HOURLY", hours = if (night) 0 else hours,
                            date = dateText ?: "", startTime = time ?: "", total = total, notes = notes.trim()
                        ))
                        saving = false
                        onDone()
                    }
                }
            }
        }
    }

    if (showDate) {
        val todayUtc = LocalDate.now().atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val st = rememberDatePickerState(selectableDates = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long) = utcTimeMillis >= todayUtc
        })
        DatePickerDialog(
            { showDate = false },
            confirmButton = { TextButton({ dateMillis = st.selectedDateMillis; showDate = false }) { Text("تأكيد") } },
            dismissButton = { TextButton({ showDate = false }) { Text("إلغاء") } }
        ) { DatePicker(st) }
    }
}

@Composable
private fun TypeCard(selected: Boolean, emoji: String, title: String, price: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp))
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
            .border(if (selected) 2.dp else 1.dp, if (selected) Gold else MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 28.sp)
        Text(title, fontWeight = FontWeight.Bold)
        Text(price, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ---------------------------------------------------------------- My bookings
@Composable
fun BookingsScreen(vm: AppVM) {
    val list by vm.myBookings.collectAsState()
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("حجوزاتي", "متابعة حالة حجوزاتك") { ThemeToggle() }
        if (list.isEmpty()) EmptyState("📅", "لا توجد حجوزات بعد\nاختر من الكادر واحجز موعدك")
        else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list, key = { it.id }) { b ->
                Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.cardElevation(2.dp)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(b.staffName, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                            StatusChip(b.status)
                        }
                        Text(if (b.type == "NIGHT") "🌙 ليلة كاملة" else "☀️ ${b.hours} ساعة")
                        Text("📅 ${b.date}  •  ${b.startTime}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        Text("الإجمالي: ${b.total.iqd()}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        if (b.status == "PENDING") TextButton({ scope.launch { Repo.setStatus(b.id, "CANCELLED") } }) { Text("إلغاء الحجز", color = Color(0xFFD64545)) }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Chat
@Composable
fun ChatScreen(
    chatId: String, admin: Boolean, title: String, subtitle: String, onBack: (() -> Unit)?, onOpenStaff: (String) -> Unit
) {
    val msgs by remember(chatId) { Repo.messages(chatId) }.collectAsState(emptyList())
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var text by remember { mutableStateOf("") }
    LaunchedEffect(msgs.size) {
        if (msgs.isNotEmpty()) listState.animateScrollToItem(msgs.lastIndex)
        if (admin) Repo.markRead(chatId)
    }
    Column(Modifier.fillMaxSize().imePadding()) {
        ScreenHeader(title, subtitle, onBack)
        if (msgs.isEmpty()) Box(Modifier.weight(1f)) { EmptyState("💬", if (admin) "لا توجد رسائل" else "ابدأ المحادثة مع الشيخة\nيمكنك إرسال ملف العضو الذي تريده من صفحته") }
        else LazyColumn(Modifier.weight(1f), state = listState, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs, key = { it.id }) { m ->
                val mine = m.fromAdmin == admin
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.Start else Arrangement.End) {
                    Column(
                        Modifier.widthIn(max = 280.dp).clip(RoundedCornerShape(18.dp))
                            .background(if (mine) Gold.copy(alpha = .85f) else MaterialTheme.colorScheme.surfaceVariant).padding(10.dp)
                    ) {
                        val fg = if (mine) PlumDark else MaterialTheme.colorScheme.onSurface
                        if (m.staffId.isNotEmpty()) {
                            Row(
                                Modifier.clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = .12f)).clickable { onOpenStaff(m.staffId) }.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (m.staffPhoto.isNotEmpty()) AsyncImage(m.staffPhoto, null, Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                                else Icon(Icons.Default.Person, null, Modifier.size(56.dp), tint = fg)
                                Spacer(Modifier.width(10.dp))
                                Column { Text("📎 ملف: ${m.staffName}", fontWeight = FontWeight.Bold, color = fg); Text("اضغط لعرض الملف", fontSize = 12.sp, color = fg.copy(alpha = .8f)) }
                            }
                            Spacer(Modifier.height(6.dp))
                        }
                        if (m.text.isNotBlank()) Text(m.text, color = fg)
                        Text(fmtTime(m.time), fontSize = 10.sp, color = fg.copy(alpha = .65f), modifier = Modifier.align(Alignment.End))
                    }
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("اكتب رسالتك…") }, shape = RoundedCornerShape(24.dp), maxLines = 4)
            FilledIconButton(
                {
                    val t = text.trim()
                    if (t.isNotEmpty()) { text = ""; scope.launch { Repo.send(chatId, Prefs.userName, Message(senderId = if (admin) "admin" else Repo.UID, fromAdmin = admin, text = t)) } }
                },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Gold, contentColor = PlumDark)
            ) { Icon(Icons.AutoMirrored.Filled.Send, null) }
        }
    }
}

// ---------------------------------------------------------------- Profile
@Composable
fun ProfileScreen(vm: AppVM) {
    val ctx = LocalContext.current
    val isAdmin by vm.isAdmin.collectAsState()
    var name by remember { mutableStateOf(Prefs.userName) }
    var phone by remember { mutableStateOf(Prefs.phone) }
    var saved by remember { mutableStateOf(false) }
    var showLogin by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("حسابي", "بياناتك والإعدادات")
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SectionTitle("بياناتي")
            OutlinedTextField(name, { name = it; saved = false }, Modifier.fillMaxWidth(), label = { Text("الاسم") }, singleLine = true, shape = RoundedCornerShape(14.dp))
            OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() }; saved = false }, Modifier.fillMaxWidth(), label = { Text("رقم الهاتف") },
                singleLine = true, shape = RoundedCornerShape(14.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone))
            GoldButton(if (saved) "تم الحفظ ✓" else "حفظ", Modifier.fillMaxWidth()) { Prefs.saveUser(name.trim(), phone); saved = true }

            SectionTitle("المظهر (نهاري / ليلي)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0 to "تلقائي", 1 to "☀️ نهاري", 2 to "🌙 ليلي").forEach { (m, t) ->
                    FilterChip(Prefs.themeMode == m, { Prefs.setTheme(m) }, { Text(t) })
                }
            }

            SectionTitle("تواصل معنا")
            OutlineGoldButton("اتصال بالشيخة", Modifier.fillMaxWidth(), Icons.Default.Call) {
                ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Config.OWNER_PHONE}")))
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(18.dp)) {
                Text("مركز الشيخة للمساج والاسترخاء. خصوصية تامة، تعقيم كامل، وحجز مرن بالساعة أو ليلة كاملة.",
                    Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 22.sp)
            }

            HorizontalDivider()
            if (isAdmin) {
                Text("أنت مسجّل كمدير ✓", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                OutlinedButton({ Repo.logout() }, Modifier.fillMaxWidth()) { Text("تسجيل خروج المدير") }
            } else TextButton({ showLogin = true }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Lock, null); Spacer(Modifier.width(6.dp)); Text("دخول الإدارة") }
            Text("الإصدار 1.0 (تجريبي محلي)", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
    if (showLogin) {
        var pin by remember { mutableStateOf("") }
        var err by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { showLogin = false },
            title = { Text("دخول الإدارة") },
            text = {
                Column {
                    OutlinedTextField(pin, { pin = it; err = false }, label = { Text("رمز المدير") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(), isError = err,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                    if (err) Text("الرمز غير صحيح", color = Color(0xFFD64545), fontSize = 12.sp)
                    Text("الرمز الافتراضي للتجربة: ${Config.ADMIN_PIN}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            },
            confirmButton = { TextButton({ if (Repo.adminLogin(pin)) showLogin = false else err = true }) { Text("دخول") } },
            dismissButton = { TextButton({ showLogin = false }) { Text("إلغاء") } }
        )
    }
}
