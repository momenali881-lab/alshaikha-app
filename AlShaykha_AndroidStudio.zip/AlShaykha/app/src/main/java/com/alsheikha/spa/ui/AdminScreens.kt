@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.alsheikha.spa.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.alsheikha.spa.data.*
import kotlinx.coroutines.launch

@Composable
fun AdminScreen(vm: AppVM, onEdit: (String) -> Unit, onChat: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val staff by vm.staff.collectAsState()
    val bookings by vm.allBookings.collectAsState()
    val chats by vm.chats.collectAsState()
    val unread = chats.sumOf { it.unreadAdmin }
    val pending = bookings.count { it.status == "PENDING" }
    Column(Modifier.fillMaxSize()) {
        ScreenHeader("لوحة الإدارة", "الكادر • الحجوزات • الرسائل") { ThemeToggle() }
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatBox("👩‍💼", "${staff?.size ?: 0}", "الكادر", Modifier.weight(1f))
            StatBox("⏳", "$pending", "حجوزات جديدة", Modifier.weight(1f))
            StatBox("💬", "$unread", "رسائل جديدة", Modifier.weight(1f))
        }
        TabRow(tab, containerColor = Color.Transparent) {
            listOf("الكادر", "الحجوزات", "الرسائل").forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t, fontWeight = FontWeight.Bold) }) }
        }
        when (tab) {
            0 -> StaffAdminList(staff.orEmpty(), onEdit)
            1 -> BookingsAdminList(bookings)
            else -> ChatsAdminList(chats, onChat)
        }
    }
}

@Composable
private fun StatBox(emoji: String, value: String, label: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, fontSize = 20.sp)
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

@Composable
private fun StaffAdminList(list: List<Staff>, onEdit: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var toDelete by remember { mutableStateOf<Staff?>(null) }
    Box(Modifier.fillMaxSize()) {
        if (list.isEmpty()) EmptyState("👩‍💼", "لا يوجد كادر بعد\nاضغط + لإضافة عضو")
        LazyColumn(contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 96.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(list, key = { it.id }) { s ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.fillMaxWidth().clickable { onEdit(s.id) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (s.photos.isNotEmpty()) AsyncImage(s.photos.first(), null, Modifier.size(60.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                        else Box(Modifier.size(60.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Gold) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.name, fontWeight = FontWeight.Bold)
                            Text("${s.photos.size} صور • ${s.pricePerHour.iqd()} / ساعة", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(if (s.available) "متاحة" else "غير متاحة", fontSize = 12.sp, color = if (s.available) Color(0xFF2E9E5B) else Color.Gray)
                        }
                        IconButton({ onEdit(s.id) }) { Icon(Icons.Default.Edit, null) }
                        IconButton({ toDelete = s }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFD64545)) }
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            { onEdit("new") }, Modifier.align(Alignment.BottomEnd).padding(16.dp),
            containerColor = Gold, contentColor = PlumDark
        ) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("إضافة عضو", fontWeight = FontWeight.Bold) }
    }
    toDelete?.let { s ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("حذف ${s.name}؟") }, text = { Text("سيتم حذف الملف وجميع صوره نهائياً.") },
            confirmButton = { TextButton({ scope.launch { Repo.deleteStaff(s) }; toDelete = null }) { Text("حذف", color = Color(0xFFD64545)) } },
            dismissButton = { TextButton({ toDelete = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
private fun BookingsAdminList(list: List<Booking>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    if (list.isEmpty()) { EmptyState("📅", "لا توجد حجوزات"); return }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(list, key = { it.id }) { b ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${b.userName} ← ${b.staffName}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        StatusChip(b.status)
                    }
                    Text(if (b.type == "NIGHT") "🌙 ليلة كاملة" else "☀️ ${b.hours} ساعة")
                    Text("📅 ${b.date} • ${b.startTime}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("📞 ${b.phone}   |   ${b.total.iqd()}", fontSize = 13.sp)
                    if (b.notes.isNotBlank()) Text("ملاحظات: ${b.notes}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton({ ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${b.phone}"))) }) { Icon(Icons.Default.Call, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("اتصال") }
                        if (b.status != "CONFIRMED") TextButton({ scope.launch { Repo.setStatus(b.id, "CONFIRMED") } }) { Text("تأكيد", color = Color(0xFF2E9E5B)) }
                        if (b.status != "CANCELLED") TextButton({ scope.launch { Repo.setStatus(b.id, "CANCELLED") } }) { Text("رفض", color = Color(0xFFD64545)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatsAdminList(list: List<ChatSummary>, onChat: () -> Unit) {
    if (list.isEmpty()) { EmptyState("💬", "لا توجد رسائل بعد"); return }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(list, key = { it.userId }) { c ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.fillMaxWidth().clickable { onChat() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(CircleShape).background(Gold), contentAlignment = Alignment.Center) { Text(c.userName.take(1), color = PlumDark, fontWeight = FontWeight.ExtraBold) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.userName, fontWeight = FontWeight.Bold)
                        Text(c.lastMessage, maxLines = 1, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(fmtTime(c.lastTime), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (c.unreadAdmin > 0) Badge(containerColor = Color(0xFFD64545)) { Text("${c.unreadAdmin}") }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Staff editor
@Composable
fun StaffEditorScreen(vm: AppVM, id: String, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val existing = remember(id) { vm.staff.value?.find { it.id == id } }
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var age by remember { mutableStateOf(existing?.age?.takeIf { it > 0 }?.toString() ?: "") }
    var bio by remember { mutableStateOf(existing?.bio ?: "") }
    var spec by remember { mutableStateOf(existing?.specialties?.joinToString("، ") ?: "") }
    var perHour by remember { mutableStateOf(existing?.pricePerHour?.toString() ?: "") }
    var night by remember { mutableStateOf(existing?.priceNight?.toString() ?: "") }
    var available by remember { mutableStateOf(existing?.available ?: true) }
    var kept by remember { mutableStateOf(existing?.photos ?: emptyList()) }
    var removed by remember { mutableStateOf(listOf<String>()) }
    var added by remember { mutableStateOf(listOf<Uri>()) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(Config.MAX_PHOTOS)) { uris ->
        val room = Config.MAX_PHOTOS - (kept.size + added.size)
        added = added + uris.take(room)
    }
    val total = kept.size + added.size

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(if (existing == null) "إضافة عضو جديد" else "تعديل الملف", "حتى ${Config.MAX_PHOTOS} صور لكل عضو", onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionTitle("الصور ($total/${Config.MAX_PHOTOS})")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                kept.forEach { u -> PhotoTile(u) { kept = kept - u; removed = removed + u } }
                added.forEach { u -> PhotoTile(u.toString()) { added = added - u } }
                if (total < Config.MAX_PHOTOS) Box(
                    Modifier.size(92.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primaryContainer)
                        .clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    contentAlignment = Alignment.Center
                ) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Add, null, tint = Gold); Text("إضافة", fontSize = 12.sp) } }
            }
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("الاسم") }, singleLine = true, shape = RoundedCornerShape(14.dp))
            OutlinedTextField(age, { age = it.filter { c -> c.isDigit() }.take(2) }, Modifier.fillMaxWidth(), label = { Text("العمر") }, singleLine = true,
                shape = RoundedCornerShape(14.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(spec, { spec = it }, Modifier.fillMaxWidth(), label = { Text("التخصصات (افصل بفاصلة)") }, shape = RoundedCornerShape(14.dp))
            OutlinedTextField(bio, { bio = it }, Modifier.fillMaxWidth(), label = { Text("نبذة") }, shape = RoundedCornerShape(14.dp), minLines = 3)
            OutlinedTextField(perHour, { perHour = it.filter { c -> c.isDigit() } }, Modifier.fillMaxWidth(), label = { Text("سعر الساعة (د.ع)") }, singleLine = true,
                shape = RoundedCornerShape(14.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            OutlinedTextField(night, { night = it.filter { c -> c.isDigit() } }, Modifier.fillMaxWidth(), label = { Text("سعر الليلة الكاملة (د.ع)") }, singleLine = true,
                shape = RoundedCornerShape(14.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            Row(verticalAlignment = Alignment.CenterVertically) { Text("متاحة للحجز", Modifier.weight(1f)); Switch(available, { available = it }) }
            error?.let { Text(it, color = Color(0xFFD64545)) }
        }
        Box(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).navigationBarsPadding().padding(12.dp)) {
            GoldButton(if (saving) "جاري الحفظ…" else "حفظ", Modifier.fillMaxWidth(), enabled = !saving, icon = Icons.Default.Check) {
                when {
                    name.isBlank() -> error = "أدخل الاسم"
                    (perHour.toLongOrNull() ?: 0) <= 0 || (night.toLongOrNull() ?: 0) <= 0 -> error = "أدخل سعر الساعة وسعر الليلة"
                    else -> scope.launch {
                        saving = true
                        try {
                            Repo.saveStaff(
                                ctx,
                                Staff(
                                    id = existing?.id ?: "", name = name.trim(), age = age.toIntOrNull() ?: 0, bio = bio.trim(),
                                    specialties = spec.split("،", ",").map { it.trim() }.filter { it.isNotEmpty() },
                                    pricePerHour = perHour.toLong(), priceNight = night.toLong(), available = available,
                                    createdAt = existing?.createdAt ?: 0
                                ),
                                kept, added, removed
                            )
                            onBack()
                        } catch (e: Exception) { error = "تعذّر الحفظ: ${e.message}" }
                        saving = false
                    }
                }
            }
        }
    }
}

@Composable
private fun PhotoTile(model: String, onRemove: () -> Unit) {
    Box(Modifier.size(92.dp).clip(RoundedCornerShape(14.dp))) {
        AsyncImage(model, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.align(Alignment.TopStart).padding(4.dp).size(24.dp).clip(CircleShape).background(Color.Black.copy(alpha = .6f)).clickable(onClick = onRemove), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Close, null, Modifier.size(16.dp), tint = Color.White)
        }
    }
}
