package com.alsheikha.spa.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import com.alsheikha.spa.data.Prefs

val Gold = Color(0xFFC9A227)
val GoldLight = Color(0xFFE8C766)
val Plum = Color(0xFF3B1F4F)
val PlumDark = Color(0xFF1B0F27)

private val DarkScheme = darkColorScheme(
    primary = GoldLight, onPrimary = PlumDark,
    secondary = Color(0xFFB48CD9), onSecondary = PlumDark,
    background = Color(0xFF110C17), onBackground = Color(0xFFF3EDE4),
    surface = Color(0xFF1C1525), onSurface = Color(0xFFF3EDE4),
    surfaceVariant = Color(0xFF2A2036), onSurfaceVariant = Color(0xFFCFC4D8),
    primaryContainer = Color(0xFF3B2A52), onPrimaryContainer = GoldLight,
    outline = Color(0xFF4A3D58)
)

private val LightScheme = lightColorScheme(
    primary = Plum, onPrimary = Color.White,
    secondary = Gold, onSecondary = PlumDark,
    background = Color(0xFFFBF7F0), onBackground = Color(0xFF241A2E),
    surface = Color.White, onSurface = Color(0xFF241A2E),
    surfaceVariant = Color(0xFFF1EADB), onSurfaceVariant = Color(0xFF5A4C66),
    primaryContainer = Color(0xFFF0E2B8), onPrimaryContainer = PlumDark,
    outline = Color(0xFFD9CFBE)
)

@Composable
fun isAppDark(): Boolean = when (Prefs.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }

@Composable
fun AlShaykhaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isAppDark()) DarkScheme else LightScheme, typography = Typography()) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(color = MaterialTheme.colorScheme.background, content = content)
        }
    }
}
