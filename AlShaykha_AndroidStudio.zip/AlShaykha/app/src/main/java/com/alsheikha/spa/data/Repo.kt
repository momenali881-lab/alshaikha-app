package com.alsheikha.spa.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

/**
 * مخزن محلي بالكامل: البيانات في ملف JSON داخل الجهاز، والصور مضغوطة في مجلد التطبيق.
 * لا يحتاج إنترنت ولا خادم.
 */
object Repo {
    const val UID = "local"

    private lateinit var ctx: Context
    private lateinit var dbFile: File
    private lateinit var imgDir: File
    private val lock = Any()

    private val _staff = MutableStateFlow<List<Staff>?>(null)
    private val _bookings = MutableStateFlow<List<Booking>>(emptyList())
    private val _messages = MutableStateFlow<List<Message>>(emptyList())
    private val _unread = MutableStateFlow(0L)
    private val _admin = MutableStateFlow(false)

    val isAdmin: Flow<Boolean> = _admin

    fun init(c: Context) {
        ctx = c.applicationContext
        dbFile = File(ctx.filesDir, "db.json")
        imgDir = File(ctx.filesDir, "staff_images").apply { mkdirs() }
        if (dbFile.exists()) load() else { seed(); save() }
    }

    // ---------- Auth (محلي) ----------
    fun adminLogin(pin: String): Boolean {
        val ok = pin == Config.ADMIN_PIN
        if (ok) _admin.value = true
        return ok
    }
    fun logout() { _admin.value = false }

    // ---------- Staff ----------
    fun staff(): Flow<List<Staff>?> = _staff

    suspend fun saveStaff(c: Context, s: Staff, kept: List<String>, newUris: List<Uri>, removed: List<String>) =
        withContext(Dispatchers.IO) {
            val id = s.id.ifEmpty { UUID.randomUUID().toString() }
            val urls = kept.toMutableList()
            for ((i, u) in newUris.withIndex()) {
                val f = File(imgDir, "${id}_${System.currentTimeMillis()}_$i.jpg")
                f.writeBytes(compress(c, u))
                urls.add(Uri.fromFile(f).toString())
            }
            removed.forEach { deleteImage(it) }
            val created = if (s.createdAt == 0L) System.currentTimeMillis() else s.createdAt
            val item = s.copy(id = id, photos = urls, createdAt = created)
            val list = _staff.value.orEmpty().toMutableList()
            val idx = list.indexOfFirst { it.id == id }
            if (idx >= 0) list[idx] = item else list.add(0, item)
            _staff.value = list.sortedByDescending { it.createdAt }
            save()
        }

    suspend fun deleteStaff(s: Staff) = withContext(Dispatchers.IO) {
        s.photos.forEach { deleteImage(it) }
        _staff.value = _staff.value.orEmpty().filter { it.id != s.id }
        save()
    }

    private fun deleteImage(url: String) {
        runCatching { Uri.parse(url).path?.let { File(it).delete() } }
    }

    /** تصغير الصور قبل الحفظ (حد أقصى 1600px، جودة 82%) للحفاظ على حجم التخزين */
    private fun compress(c: Context, uri: Uri): ByteArray {
        val cr = c.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts)!! }
        val deg = cr.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
        if (deg != 0) {
            val m = Matrix().apply { postRotate(deg.toFloat()) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val scale = 1600f / maxOf(bmp.width, bmp.height)
        if (scale < 1f) bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
        return out.toByteArray()
    }

    // ---------- Bookings ----------
    fun myBookings(uid: String): Flow<List<Booking>> =
        _bookings.map { l -> l.filter { it.userId == uid }.sortedByDescending { it.createdAt } }

    fun allBookings(): Flow<List<Booking>> = _bookings.map { l -> l.sortedByDescending { it.createdAt } }

    suspend fun createBooking(b: Booking) {
        _bookings.value = _bookings.value + b.copy(id = UUID.randomUUID().toString(), createdAt = System.currentTimeMillis())
        withContext(Dispatchers.IO) { save() }
    }

    suspend fun setStatus(id: String, status: String) {
        _bookings.value = _bookings.value.map { if (it.id == id) it.copy(status = status) else it }
        withContext(Dispatchers.IO) { save() }
    }

    // ---------- Chat (محادثة واحدة بين العميل والمالكة) ----------
    fun messages(chatId: String): Flow<List<Message>> = _messages

    fun chats(): Flow<List<ChatSummary>> = combine(_messages, _unread) { msgs, unread ->
        val last = msgs.lastOrNull()
        if (last == null) emptyList() else listOf(
            ChatSummary(
                userId = UID,
                userName = Prefs.userName.ifBlank { "العميل" },
                lastMessage = if (last.staffId.isNotEmpty()) "📎 ملف: ${last.staffName}" else last.text,
                lastTime = last.time,
                unreadAdmin = unread
            )
        )
    }

    suspend fun send(chatId: String, userName: String, m: Message) {
        _messages.value = _messages.value + m.copy(id = UUID.randomUUID().toString(), time = System.currentTimeMillis())
        _unread.value = if (m.fromAdmin) 0L else _unread.value + 1
        withContext(Dispatchers.IO) { save() }
    }

    suspend fun markRead(chatId: String) {
        if (_unread.value != 0L) { _unread.value = 0L; withContext(Dispatchers.IO) { save() } }
    }

    // ---------- التخزين ----------
    private fun save() = synchronized(lock) {
        val o = JSONObject()
        o.put("unread", _unread.value)
        o.put("staff", JSONArray().also { a -> _staff.value.orEmpty().forEach { a.put(staffJson(it)) } })
        o.put("bookings", JSONArray().also { a -> _bookings.value.forEach { a.put(bookingJson(it)) } })
        o.put("messages", JSONArray().also { a -> _messages.value.forEach { a.put(messageJson(it)) } })
        dbFile.writeText(o.toString())
    }

    private fun load() {
        val o = runCatching { JSONObject(dbFile.readText()) }.getOrElse { seed(); return }
        _unread.value = o.optLong("unread")
        _staff.value = o.optJSONArray("staff").objs().map(::staffFrom).sortedByDescending { it.createdAt }
        _bookings.value = o.optJSONArray("bookings").objs().map(::bookingFrom)
        _messages.value = o.optJSONArray("messages").objs().map(::messageFrom)
    }

    private fun seed() {
        val now = System.currentTimeMillis()
        _staff.value = listOf(
            Staff("demo1", "ليلى", 26, "مدلّكة محترفة بخبرة 6 سنوات في المساج السويدي والأروماثيرابي. (بيانات تجريبية - يمكنك حذفها)",
                listOf("مساج سويدي", "أروماثيرابي"), emptyList(), 25000, 120000, true, now),
            Staff("demo2", "سارة", 29, "متخصصة في مساج الأحجار الساخنة وتدليك الظهر والكتفين. (بيانات تجريبية)",
                listOf("أحجار ساخنة", "مساج رياضي"), emptyList(), 30000, 150000, true, now - 1)
        )
    }

    private fun JSONArray?.objs(): List<JSONObject> = if (this == null) emptyList() else (0 until length()).map { getJSONObject(it) }
    private fun JSONArray?.strs(): List<String> = if (this == null) emptyList() else (0 until length()).map { getString(it) }

    private fun staffJson(s: Staff) = JSONObject().put("id", s.id).put("name", s.name).put("age", s.age).put("bio", s.bio)
        .put("specialties", JSONArray(s.specialties)).put("photos", JSONArray(s.photos))
        .put("pricePerHour", s.pricePerHour).put("priceNight", s.priceNight).put("available", s.available).put("createdAt", s.createdAt)

    private fun staffFrom(o: JSONObject) = Staff(
        o.optString("id"), o.optString("name"), o.optInt("age"), o.optString("bio"),
        o.optJSONArray("specialties").strs(), o.optJSONArray("photos").strs(),
        o.optLong("pricePerHour"), o.optLong("priceNight"), o.optBoolean("available", true), o.optLong("createdAt")
    )

    private fun bookingJson(b: Booking) = JSONObject().put("id", b.id).put("userId", b.userId).put("userName", b.userName)
        .put("phone", b.phone).put("staffId", b.staffId).put("staffName", b.staffName).put("type", b.type).put("hours", b.hours)
        .put("date", b.date).put("startTime", b.startTime).put("total", b.total).put("status", b.status)
        .put("notes", b.notes).put("createdAt", b.createdAt)

    private fun bookingFrom(o: JSONObject) = Booking(
        o.optString("id"), o.optString("userId"), o.optString("userName"), o.optString("phone"),
        o.optString("staffId"), o.optString("staffName"), o.optString("type"), o.optInt("hours", 1),
        o.optString("date"), o.optString("startTime"), o.optLong("total"), o.optString("status"),
        o.optString("notes"), o.optLong("createdAt")
    )

    private fun messageJson(m: Message) = JSONObject().put("id", m.id).put("senderId", m.senderId).put("fromAdmin", m.fromAdmin)
        .put("text", m.text).put("staffId", m.staffId).put("staffName", m.staffName).put("staffPhoto", m.staffPhoto).put("time", m.time)

    private fun messageFrom(o: JSONObject) = Message(
        o.optString("id"), o.optString("senderId"), o.optBoolean("fromAdmin"), o.optString("text"),
        o.optString("staffId"), o.optString("staffName"), o.optString("staffPhoto"), o.optLong("time")
    )
}
