package com.alsheikha.spa

import android.app.Application
import com.alsheikha.spa.data.Prefs
import com.alsheikha.spa.data.Repo

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Repo.init(this)
    }
}
