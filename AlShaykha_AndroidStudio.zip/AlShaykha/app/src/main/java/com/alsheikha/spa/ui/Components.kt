package com.alsheikha.spa.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.alsheikha.spa.data.Prefs
import com.alsheikha.spa.data.Staff
import com.alsheikha.spa.data.iqd
import com.alsheikha.spa.data.statusLabel

@Composable
fun GoldButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, icon: ImageVector? = null, onClick: () -> Unit) {
    val bg = if (enabled) Brush.horizontalGradient(listOf(Gold, GoldLight, Gold)) else SolidColor(Color.Gray.copy(alpha = .4f))
    Box(
        modifier.height(54.dp).clip(RoundedCornerShape(16.dp)).background(bg).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) Icon(icon, null, tint = PlumDark)
            Text(text, color = PlumDark, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun OutlineGoldButton(text: String, modifier: Modifier = Modifier, icon: ImageVector? = null, onClick: () -> Unit) {
    Box(
        modifier.height(54.dp).clip(RoundedCornerShape(16.dp)).border(1.5.dp, Gold, RoundedCornerShape(16.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Text(text, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null, onBack: (() -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    Box(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(Brush.verticalGradient(listOf(Plum, PlumDark)))
            .statusBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
            else Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = GoldLight, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                if (subtitle != null) Text(subtitle, color = Color.White.copy(alpha = .75f), fontSize = 12.sp)
            }
            actions()
        }
    }
}

@Composable
fun ThemeToggle() {
    val dark = isAppDark()
    IconButton({ Prefs.setTheme(if (dark) 1 else 2) }) { Text(if (dark) "☀️" else "🌙", fontSize = 20.sp) }
}

@Composable
fun LoadingBox() = Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Gold) }

@Composable
fun EmptyState(emoji: String, text: String) {
    Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, fontSize = 48.sp)
        Spacer(Modifier.height(8.dp))
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(18.dp).clip(RoundedCornerShape(2.dp)).background(Gold))
        Spacer(Modifier.width(8.dp))
        Text(text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

@Composable
fun StatusChip(s: String) {
    val c = when (s) { "CONFIRMED" -> Color(0xFF2E9E5B); "CANCELLED" -> Color(0xFFD64545); else -> Color(0xFFE0A100) }
    Box(Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = .15f)).padding(horizontal = 12.dp, vertical = 4.dp)) {
        Text(statusLabel(s), color = c, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun StaffCard(s: Staff, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(.8f)) {
            if (s.photos.isNotEmpty()) AsyncImage(s.photos.first(), s.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, null, Modifier.size(56.dp), tint = Gold)
            }
            Box(
                Modifier.align(Alignment.TopStart).padding(8.dp).clip(RoundedCornerShape(50))
                    .background(if (s.available) Color(0xFF2E9E5B) else Color(0xFF8A8A8A)).padding(horizontal = 10.dp, vertical = 3.dp)
            ) { Text(if (s.available) "متاحة" else "غير متاحة", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            if (s.photos.size > 1) Box(
                Modifier.align(Alignment.TopEnd).padding(8.dp).clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = .55f)).padding(horizontal = 8.dp, vertical = 3.dp)
            ) { Text("📷 ${s.photos.size}", color = Color.White, fontSize = 11.sp) }
            Box(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = .75f)))).padding(12.dp)
            ) { Text(s.name + if (s.age > 0) "، ${s.age}" else "", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) }
        }
        Column(Modifier.padding(10.dp)) {
            Text("☀️ ${s.pricePerHour.iqd()} / ساعة", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("🌙 ${s.priceNight.iqd()} / ليلة", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}
