package com.alsheikha.spa.data

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Config {
    /** رمز دخول المدير (للتجربة المحلية) - غيّره كما تريد */
    const val ADMIN_PIN = "1234"
    const val CENTER_NAME = "الشيخة"
    /** رقم هاتفك للاتصال المباشر */
    const val OWNER_PHONE = "07700000000"
    const val MAX_PHOTOS = 10
}

fun Long.iqd(): String = NumberFormat.getInstance(Locale.US).format(this) + " د.ع"

fun fmtHour(h: Int): String {
    val suffix = if (h < 12) "ص" else "م"
    val hh = if (h % 12 == 0) 12 else h % 12
    return "$hh:00 $suffix"
}

fun fmtTime(ms: Long): String = SimpleDateFormat("hh:mm a", Locale("ar")).format(Date(ms))

fun statusLabel(s: String) = when (s) { "CONFIRMED" -> "مؤكد"; "CANCELLED" -> "ملغي"; else -> "قيد المراجعة" }
