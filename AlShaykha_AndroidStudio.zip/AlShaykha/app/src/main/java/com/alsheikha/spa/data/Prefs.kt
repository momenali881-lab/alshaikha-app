package com.alsheikha.spa.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

object Prefs {
    private var sp: SharedPreferences? = null
    /** 0 تلقائي، 1 نهاري، 2 ليلي */
    var themeMode by mutableStateOf(0)
        private set
    var userName by mutableStateOf("")
        private set
    var phone by mutableStateOf("")
        private set

    fun init(c: Context) {
        val s = c.getSharedPreferences("alsheikha", Context.MODE_PRIVATE)
        sp = s
        themeMode = s.getInt("theme", 0)
        userName = s.getString("name", "") ?: ""
        phone = s.getString("phone", "") ?: ""
    }

    fun setTheme(v: Int) { themeMode = v; sp?.edit()?.putInt("theme", v)?.apply() }

    fun saveUser(n: String, p: String) {
        userName = n; phone = p
        sp?.edit()?.putString("name", n)?.putString("phone", p)?.apply()
    }
}
