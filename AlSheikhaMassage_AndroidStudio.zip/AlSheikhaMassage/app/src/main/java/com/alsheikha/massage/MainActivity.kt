package com.alsheikha.massage

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import coil.compose.AsyncImage
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Teal = Color(0xFF1F6B62)
private val Gold = Color(0xFFC49A55)
private val Ink = Color(0xFF173331)

data class Member(val id: Long, val name: String, val specialty: String, val bio: String, val hourly: Int, val overnight: Int, val photos: List<String>)
data class Booking(val id: Long, val member: String, val service: String, val date: String, val time: String, val price: Int, val status: String)
data class ChatMsg(val text: String, val fromAdmin: Boolean, val memberName: String = "")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SheikhaApp(this) }
    }
}

@Composable
fun SheikhaApp(ctx: Context) {
    val prefs = remember { ctx.getSharedPreferences("sheikha_local", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var admin by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf("الرئيسية") }
    var members by remember { mutableStateOf(loadMembers(prefs)) }
    var bookings by remember { mutableStateOf(loadBookings(prefs)) }
    var messages by remember { mutableStateOf(loadMessages(prefs)) }
    var selected by remember { mutableStateOf<Member?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var showBooking by remember { mutableStateOf<Member?>(null) }
    var chatText by remember { mutableStateOf("") }
    val bg = if (dark) Color(0xFF101C1B) else Color(0xFFF5F3EE)
    val surface = if (dark) Color(0xFF1B2B29) else Color.White
    val text = if (dark) Color(0xFFEAF1EC) else Ink
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary=Color(0xFF79C6B7), secondary=Gold, background=bg, surface=surface) else lightColorScheme(primary=Teal, secondary=Gold, background=bg, surface=surface)) {
        Scaffold(containerColor=bg, bottomBar = {
            NavigationBar(containerColor=surface) {
                listOf("الرئيسية","الكادر","حجوزاتي","الدردشة","الإعدادات").forEach { item ->
                    NavigationBarItem(selected=tab==item, onClick={tab=item; selected=null}, icon={
                        Icon(when(item){"الرئيسية"->Icons.Default.Home;"الكادر"->Icons.Default.Groups;"حجوزاتي"->Icons.Default.EventAvailable;"الدردشة"->Icons.Default.Chat;"الإعدادات"->Icons.Default.Settings;else->Icons.Default.Home}, null)
                    }, label={Text(item, fontSize=10.sp)})
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(bg)) {
                Header(dark, text, admin) { admin = !admin }
                when {
                    selected != null -> MemberDetail(selected!!, admin, text, onBack={selected=null}, onBook={showBooking=selected}, onShare={
                        messages = messages + ChatMsg("أرغب بالاستفسار عن هذا العضو", false, selected!!.name); saveMessages(prefs,messages); tab="الدردشة"; selected=null
                    })
                    showAdd -> AddMemberScreen(text, onCancel={showAdd=false}, onSave={m ->
                        members = members + m; saveMembers(prefs,members); showAdd=false
                    }, ctx=ctx)
                    showBooking != null -> BookingScreen(showBooking!!, text, onCancel={showBooking=null}, onConfirm={service,date,time,price ->
                        bookings = bookings + Booking(System.currentTimeMillis(),showBooking!!.name,service,date,time,price,"قيد المراجعة")
                        saveBookings(prefs,bookings); showBooking=null; tab="حجوزاتي"
                    })
                    else -> when(tab) {
                        "الرئيسية" -> HomeScreen(text, members.size, bookings.size, onBrowse={tab="الكادر"}, onChat={tab="الدردشة"})
                        "الكادر" -> StaffScreen(members,text,admin,onSelect={selected=it},onAdd={showAdd=true})
                        "حجوزاتي" -> BookingsScreen(bookings,text,admin,onStatus={id,status ->
                            bookings=bookings.map{if(it.id==id)it.copy(status=status)else it};saveBookings(prefs,bookings)
                        })
                        "الدردشة" -> ChatScreen(messages,text,chatText,{chatText=it},admin,{ 
                            if(chatText.isNotBlank()){messages=messages+ChatMsg(chatText.trim(),admin);saveMessages(prefs,messages);chatText=""}
                        })
                        else -> SettingsScreen(text,dark,{dark=it;prefs.edit().putBoolean("dark",it).apply()},admin,{admin=it},onReset={
                            members=emptyList();bookings=emptyList();messages=emptyList()
                            saveMembers(prefs,members);saveBookings(prefs,bookings);saveMessages(prefs,messages)
                        })
                    }
                }
            }
        }
    }
}

@Composable fun Header(dark:Boolean, text:Color, admin:Boolean, toggle:()->Unit) {
    Row(Modifier.fillMaxWidth().background(if(dark)Color(0xFF172A28) else Ink).padding(horizontal=18.dp, vertical=16.dp), verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Gold),contentAlignment=Alignment.Center){Text("ش",fontSize=25.sp,fontWeight=FontWeight.Bold,color=Ink)}
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)){Text("الشيخة",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Bold);Text("مركز العناية والاسترخاء",color=Color(0xFFD7E2DC),fontSize=11.sp)}
        TextButton(onClick=toggle){Text(if(admin)"وضع الإدارة" else "وضع العميل",color=Color.White,fontSize=11.sp)}
    }
}
@Composable fun HomeScreen(text:Color, count:Int, bookings:Int,onBrowse:()->Unit,onChat:()->Unit){
    LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item { Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.horizontalGradient(listOf(Ink,Teal))).padding(22.dp)){
            Text("أهلاً بك في الشيخة",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.Bold)
            Spacer(Modifier.height(8.dp));Text("مساحة هادئة للعناية والراحة، مع حجز سهل وخدمة منظمة.",color=Color.White.copy(.85f),fontSize=14.sp)
            Spacer(Modifier.height(18.dp));Button(onClick=onBrowse,colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Ink),shape=RoundedCornerShape(14.dp)){Text("استعرض الكادر")}
        }}
        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){StatCard("أعضاء الكادر",count.toString(),Icons.Default.Groups,Modifier.weight(1f));StatCard("الحجوزات",bookings.toString(),Icons.Default.Event,Modifier.weight(1f))} }
        item { SectionTitle("خدماتنا",text) }
        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){ServiceCard("جلسة بالساعة","حجز مرن حسب التوفر",Icons.Default.Schedule,Modifier.weight(1f));ServiceCard("ليلة كاملة","طلب حجز مسبق",Icons.Default.Bed,Modifier.weight(1f))} }
        item { Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(20.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.SupportAgent,null,tint=Teal,modifier=Modifier.size(32.dp));Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text("تواصل مباشر مع الإدارة",fontWeight=FontWeight.Bold,color=text);Text("أرسل استفسارك أو شارك ملف العضو",fontSize=12.sp,color=text.copy(.65f))};Button(onClick=onChat){Text("الدردشة")}}} }
        item { Text("ملاحظة: هذه نسخة تجريبية تحفظ البيانات على هذا الهاتف فقط.",fontSize=11.sp,color=text.copy(.55f),textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth().padding(8.dp)) }
    }
}
@Composable fun StatCard(title:String,value:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier=Modifier){Card(modifier,shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Icon(icon,null,tint=Gold);Text(value,fontSize=25.sp,fontWeight=FontWeight.Bold);Text(title,fontSize=12.sp,color=Ink.copy(.6f))}}}
@Composable fun ServiceCard(title:String,sub:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier=Modifier){Card(modifier,shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp)){Icon(icon,null,tint=Teal);Spacer(Modifier.height(8.dp));Text(title,fontWeight=FontWeight.Bold);Text(sub,fontSize=11.sp,color=Ink.copy(.6f))}}}
@Composable fun SectionTitle(title:String,text:Color){Text(title,fontSize=18.sp,fontWeight=FontWeight.Bold,color=text)}
@Composable fun StaffScreen(members:List<Member>,text:Color,admin:Boolean,onSelect:(Member)->Unit,onAdd:()->Unit){
    Column(Modifier.fillMaxSize().padding(18.dp)){
        Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("الكادر",fontSize=24.sp,fontWeight=FontWeight.Bold,color=text);Text("ملفات الأعضاء والخدمات والأسعار",fontSize=12.sp,color=text.copy(.6f))};if(admin)Button(onClick=onAdd){Icon(Icons.Default.Add,null);Text("إضافة")}}
        Spacer(Modifier.height(12.dp))
        if(members.isEmpty()) EmptyState("لا يوجد أعضاء حتى الآن","فعّل وضع الإدارة ثم أضف أول عضو في الكادر")
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(members){m->Card(Modifier.fillMaxWidth().clickable{onSelect(m)},shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(54.dp).clip(CircleShape).background(Color(0xFFE3EDE8)),contentAlignment=Alignment.Center){Icon(Icons.Default.Person,null,tint=Teal,modifier=Modifier.size(30.dp))};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(m.name,fontWeight=FontWeight.Bold,color=text);Text(m.specialty,color=text.copy(.6f),fontSize=12.sp);Text("الساعة: ${m.hourly} د.ع  •  الليلة: ${m.overnight} د.ع",fontSize=11.sp,color=Gold)};Icon(Icons.Default.ChevronLeft,null,tint=Teal)}}}}
    }
}
@Composable fun MemberDetail(m:Member,admin:Boolean,text:Color,onBack:()->Unit,onBook:()->Unit,onShare:()->Unit){
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)){
        TextButton(onClick=onBack){Text("رجوع")}
        Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Teal,Ink))),contentAlignment=Alignment.Center){Icon(Icons.Default.Spa,null,tint=Gold,modifier=Modifier.size(70.dp))}
        Spacer(Modifier.height(14.dp))
        if(m.photos.isNotEmpty()) {
            Text("معرض الصور",fontWeight=FontWeight.Bold,color=text)
            Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                m.photos.forEach { uri -> AsyncImage(model=uri,contentDescription="صورة العضو",modifier=Modifier.size(118.dp).clip(RoundedCornerShape(14.dp))) }
            }
        }
        Text(m.name,fontSize=25.sp,fontWeight=FontWeight.Bold,color=text);Text(m.specialty,color=Gold);Text(m.bio.ifBlank{"عضو ضمن كادر مركز الشيخة للعناية والاسترخاء."},color=text.copy(.8f),modifier=Modifier.padding(vertical=12.dp))
        Text("الصور المضافة: ${m.photos.size} / 10",color=text);Text("سعر الساعة: ${m.hourly} د.ع",fontWeight=FontWeight.Bold,color=text);Text("سعر الليلة كاملة: ${m.overnight} د.ع",fontWeight=FontWeight.Bold,color=text)
        Spacer(Modifier.height(20.dp));Button(onClick=onBook,modifier=Modifier.fillMaxWidth()){Text("طلب حجز")};OutlinedButton(onClick=onShare,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Send,null);Spacer(Modifier.width(8.dp));Text("إرسال ملف العضو إلى الإدارة")}
    }
}
@Composable fun AddMemberScreen(text:Color,onCancel:()->Unit,onSave:(Member)->Unit,ctx:Context){
    var name by remember{mutableStateOf("")};var specialty by remember{mutableStateOf("مساج استرخائي")};var bio by remember{mutableStateOf("")};var hourly by remember{mutableStateOf("50000")};var night by remember{mutableStateOf("150000")};var photos by remember{mutableStateOf(listOf<String>())}
    val picker= rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()){uris->
        uris.forEach { uri -> try { ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_:Exception) {} }
        photos=(photos+uris.map{it.toString()}).distinct().take(10)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        TextButton(onClick=onCancel){Text("إلغاء")}
        Text("إضافة عضو جديد",fontSize=24.sp,fontWeight=FontWeight.Bold,color=text)
        OutlinedTextField(name,{name=it},label={Text("اسم العضو")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        OutlinedTextField(specialty,{specialty=it},label={Text("نوع الخدمة")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        OutlinedTextField(bio,{bio=it},label={Text("نبذة تعريفية")},modifier=Modifier.fillMaxWidth(),minLines=2)
        OutlinedTextField(hourly,{hourly=it.filter(Char::isDigit)},label={Text("سعر الساعة بالدينار العراقي")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(night,{night=it.filter(Char::isDigit)},label={Text("سعر الليلة كاملة بالدينار العراقي")},modifier=Modifier.fillMaxWidth())
        OutlinedButton(onClick={picker.launch(arrayOf("image/*"))},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.AddPhotoAlternate,null);Text("اختيار الصور (${photos.size}/10)")}
        Text("تُحفظ مراجع الصور محلياً؛ قد تحتاج إعادة اختيار الصور إذا أزيل إذن الوصول.",fontSize=11.sp,color=text.copy(.6f))
        Button(onClick={if(name.isNotBlank())onSave(Member(System.currentTimeMillis(),name,specialty,bio,hourly.toIntOrNull()?:0,night.toIntOrNull()?:0,photos))},modifier=Modifier.fillMaxWidth(),enabled=name.isNotBlank()){Text("حفظ العضو")}
    }
}
@Composable fun BookingScreen(m:Member,text:Color,onCancel:()->Unit,onConfirm:(String,String,String,Int)->Unit){
    var service by remember{mutableStateOf("بالساعة")};var date by remember{mutableStateOf("")};var time by remember{mutableStateOf("")}
    val price=if(service=="بالساعة")m.hourly else m.overnight
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        TextButton(onClick=onCancel){Text("رجوع")};Text("طلب حجز",fontSize=24.sp,fontWeight=FontWeight.Bold,color=text);Text("العضو: ${m.name}",color=Gold)
        Text("نوع الحجز",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(selected=service=="بالساعة",onClick={service="بالساعة"},label={Text("بالساعة")});FilterChip(selected=service=="ليلة كاملة",onClick={service="ليلة كاملة"},label={Text("ليلة كاملة")})}
        OutlinedTextField(date,{date=it},label={Text("التاريخ (مثال 2026/12/01)")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(time,{time=it},label={Text("الوقت")},modifier=Modifier.fillMaxWidth())
        Card{Column(Modifier.padding(16.dp)){Text("السعر التقديري",color=text.copy(.6f));Text("$price د.ع",fontSize=24.sp,fontWeight=FontWeight.Bold,color=Teal)}}
        Button(onClick={onConfirm(service,date,time,price)},modifier=Modifier.fillMaxWidth(),enabled=date.isNotBlank()&&time.isNotBlank()){Text("تأكيد طلب الحجز")}
    }
}
@Composable fun BookingsScreen(bookings:List<Booking>,text:Color,admin:Boolean,onStatus:(Long,String)->Unit){
    Column(Modifier.fillMaxSize().padding(18.dp)){Text("حجوزاتي",fontSize=24.sp,fontWeight=FontWeight.Bold,color=text);Spacer(Modifier.height(12.dp))
        if(bookings.isEmpty())EmptyState("لا توجد حجوزات","ستظهر طلبات الحجز هنا")
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(bookings){b->Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text(b.member,fontWeight=FontWeight.Bold,color=text);Text("${b.service} • ${b.date} • ${b.time}",fontSize=12.sp,color=text.copy(.7f));Text("${b.price} د.ع",color=Gold,fontWeight=FontWeight.Bold);Text("الحالة: ${b.status}",color=Teal);if(admin)Row{TextButton(onClick={onStatus(b.id,"مؤكد")}){Text("تأكيد")};TextButton(onClick={onStatus(b.id,"مرفوض")}){Text("رفض")}}}}}}
    }
}
@Composable fun ChatScreen(messages:List<ChatMsg>,text:Color,value:String,onValue:(String)->Unit,admin:Boolean,onSend:()->Unit){
    Column(Modifier.fillMaxSize().padding(16.dp)){
        Text(if(admin)"صندوق رسائل العملاء" else "الدردشة مع الإدارة",fontSize=23.sp,fontWeight=FontWeight.Bold,color=text);Text(if(admin)"أنت ترد بصفتك إدارة المركز" else "المراسلة هنا مع إدارة مركز الشيخة مباشرة",fontSize=12.sp,color=text.copy(.6f));Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(8.dp)){items(messages){m->Row(Modifier.fillMaxWidth(),horizontalArrangement=if(m.fromAdmin)Arrangement.Start else Arrangement.End){Column(Modifier.widthIn(max=290.dp).clip(RoundedCornerShape(16.dp)).background(if(m.fromAdmin)Color(0xFFE1EBE6) else Color(0xFFDCEBE8)).padding(12.dp)){if(m.memberName.isNotBlank())Text("ملف عضو مرفق: ${m.memberName}",fontWeight=FontWeight.Bold,color=Teal,fontSize=12.sp);Text(m.text,color=Ink);Text(if(m.fromAdmin)"الإدارة" else "أنت",fontSize=10.sp,color=Ink.copy(.55f))}}}}
        Row(verticalAlignment=Alignment.CenterVertically){OutlinedTextField(value,onValue,modifier=Modifier.weight(1f),placeholder={Text("اكتب رسالتك...")},maxLines=3);IconButton(onClick=onSend,enabled=value.isNotBlank()){Icon(Icons.Default.Send,null,tint=Teal)}}
    }
}
@Composable fun SettingsScreen(text:Color,dark:Boolean,onDark:(Boolean)->Unit,admin:Boolean,onAdmin:(Boolean)->Unit,onReset:()->Unit){
    var confirm by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("الإعدادات",fontSize=24.sp,fontWeight=FontWeight.Bold,color=text)
        Card{Column(Modifier.padding(16.dp)){Text("المظهر",fontWeight=FontWeight.Bold);Row(verticalAlignment=Alignment.CenterVertically){Text("الوضع الليلي",modifier=Modifier.weight(1f));Switch(dark,onDark)}}}
        Card{Column(Modifier.padding(16.dp)){Text("نوع الاستخدام",fontWeight=FontWeight.Bold);Row(verticalAlignment=Alignment.CenterVertically){Text("وضع الإدارة",modifier=Modifier.weight(1f));Switch(admin,onAdmin)};Text("نسخة تجريبية محلية على جهاز واحد. لا يوجد مزامنة أو استقبال رسائل عن بُعد.",fontSize=11.sp,color=text.copy(.6f))}}
        Card{Column(Modifier.padding(16.dp)){Text("العملة",fontWeight=FontWeight.Bold);Text("الدينار العراقي (د.ع)")}}
        OutlinedButton(onClick={confirm=true},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.Delete,null);Text("مسح بيانات التجربة")}
        if(confirm)AlertDialog(onDismissRequest={confirm=false},title={Text("مسح البيانات؟")},text={Text("سيتم حذف الأعضاء والحجوزات والرسائل المخزنة محلياً.")},confirmButton={TextButton(onClick={onReset();confirm=false}){Text("مسح")}},dismissButton={TextButton(onClick={confirm=false}){Text("إلغاء")}})
    }
}
@Composable fun EmptyState(title:String,sub:String){Column(Modifier.fillMaxWidth().padding(vertical=32.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Inbox,null,tint=Gold,modifier=Modifier.size(42.dp));Spacer(Modifier.height(8.dp));Text(title,fontWeight=FontWeight.Bold);Text(sub,fontSize=12.sp,color=Ink.copy(.55f),textAlign=TextAlign.Center)}}

fun loadMembers(p:android.content.SharedPreferences):List<Member> = try { val a=JSONArray(p.getString("members","[]"));(0 until a.length()).map{val o=a.getJSONObject(it);Member(o.getLong("id"),o.getString("name"),o.getString("specialty"),o.getString("bio"),o.getInt("hourly"),o.getInt("overnight"),o.getJSONArray("photos").let{j->(0 until j.length()).map{j.getString(it)}})} }catch(_:Exception){emptyList()}
fun saveMembers(p:android.content.SharedPreferences,items:List<Member>){val a=JSONArray();items.forEach{m->a.put(JSONObject().put("id",m.id).put("name",m.name).put("specialty",m.specialty).put("bio",m.bio).put("hourly",m.hourly).put("overnight",m.overnight).put("photos",JSONArray(m.photos)))};p.edit().putString("members",a.toString()).apply()}
fun loadBookings(p:android.content.SharedPreferences):List<Booking> = try {val a=JSONArray(p.getString("bookings","[]"));(0 until a.length()).map{val o=a.getJSONObject(it);Booking(o.getLong("id"),o.getString("member"),o.getString("service"),o.getString("date"),o.getString("time"),o.getInt("price"),o.getString("status"))}}catch(_:Exception){emptyList()}
fun saveBookings(p:android.content.SharedPreferences,items:List<Booking>){val a=JSONArray();items.forEach{b->a.put(JSONObject().put("id",b.id).put("member",b.member).put("service",b.service).put("date",b.date).put("time",b.time).put("price",b.price).put("status",b.status))};p.edit().putString("bookings",a.toString()).apply()}
fun loadMessages(p:android.content.SharedPreferences):List<ChatMsg> = try {val a=JSONArray(p.getString("messages","[]"));(0 until a.length()).map{val o=a.getJSONObject(it);ChatMsg(o.getString("text"),o.getBoolean("admin"),o.optString("member",""))}}catch(_:Exception){emptyList()}
fun saveMessages(p:android.content.SharedPreferences,items:List<ChatMsg>){val a=JSONArray();items.forEach{m->a.put(JSONObject().put("text",m.text).put("admin",m.fromAdmin).put("member",m.memberName))};p.edit().putString("messages",a.toString()).apply()}
