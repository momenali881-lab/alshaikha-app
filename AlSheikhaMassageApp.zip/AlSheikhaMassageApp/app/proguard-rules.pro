# ProGuard rules for Al-Sheikha Massage App
-keep class com.alsheikha.massage.** { *; }
