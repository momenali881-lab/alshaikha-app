package com.alsheikha.massage.model

import java.util.UUID

data class StaffMember(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val hasPrivatePlace: Boolean,
    val isAvailable: Boolean = true,
    val hourlyRateIqd: Long,
    val fullNightRateIqd: Long,
    val bio: String = "",
    val photos: List<String> = emptyList() // Up to 10 URIs or Base64/Asset paths
)

enum class BookingType(val labelAr: String) {
    HOURLY("حجز بالساعات"),
    FULL_NIGHT("حجز ليلة كاملة")
}

data class BookingRequest(
    val id: String = UUID.randomUUID().toString(),
    val staffId: String,
    val staffName: String,
    val hasPrivatePlace: Boolean,
    val bookingType: BookingType,
    val hours: Int = 1,
    val date: String,
    val time: String,
    val totalPriceIqd: Long,
    val clientNotes: String = ""
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val senderIsAdmin: Boolean,
    val text: String,
    val timestamp: String,
    val attachedStaff: StaffMember? = null
)
