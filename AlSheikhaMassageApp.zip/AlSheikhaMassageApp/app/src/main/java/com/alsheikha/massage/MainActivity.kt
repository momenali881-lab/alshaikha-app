package com.alsheikha.massage

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.alsheikha.massage.data.LocalStorageManager
import com.alsheikha.massage.model.*
import com.alsheikha.massage.ui.theme.AlSheikhaTheme
import com.alsheikha.massage.ui.theme.RoyalGold
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val context = LocalContext.current
            val storage = remember { LocalStorageManager(context) }
            var isDark by remember { mutableStateOf(storage.isDarkMode()) }

            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                AlSheikhaTheme(darkTheme = isDark) {
                    AlSheikhaApp(
                        storage = storage,
                        isDark = isDark,
                        onToggleTheme = {
                            isDark = !isDark
                            storage.setDarkMode(isDark)
                        }
                    )
                }
            }
        }
    }
}

fun formatIqd(amount: Long): String {
    val formatter = NumberFormat.getInstance(Locale.US)
    return "${formatter.format(amount)} د.ع"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlSheikhaApp(
    storage: LocalStorageManager,
    isDark: Boolean,
    onToggleTheme: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var isAdminMode by remember { mutableStateOf(true) }
    var staffList by remember { mutableStateOf(storage.getStaffList()) }
    var bookings by remember { mutableStateOf(storage.getBookings()) }
    var messages by remember { mutableStateOf(storage.getChatMessages()) }

    var selectedStaffForBooking by remember { mutableStateOf<StaffMember?>(null) }
    var editingStaff by remember { mutableStateOf<StaffMember?>(null) }
    var showAddEditDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("مركز الشيخة", fontWeight = FontWeight.Bold, color = RoyalGold, fontSize = 20.sp)
                        Text(
                            if (isAdminMode) "وضع الإدارة المتكامل" else "واجهة العملاء",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                },
                actions = {
                    FilterChip(
                        selected = isAdminMode,
                        onClick = { isAdminMode = !isAdminMode },
                        label = { Text(if (isAdminMode) "إدارة" else "عميل", fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(
                                if (isAdminMode) Icons.Default.AdminPanelSettings else Icons.Default.Person,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                    IconButton(onClick = onToggleTheme) {
                        Icon(
                            if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "تبديل المظهر",
                            tint = RoyalGold
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Groups, contentDescription = null) },
                    label = { Text("الكادر") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.EventAvailable, contentDescription = null) },
                    label = { Text("الحجوزات") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Chat, contentDescription = null) },
                    label = { Text("دردشة الإدارة") }
                )
                if (isAdminMode) {
                    NavigationBarItem(
                        selected = selectedTab == 3,
                        onClick = { selectedTab = 3 },
                        icon = { Icon(Icons.Default.ManageAccounts, contentDescription = null) },
                        label = { Text("إدارة الأعضاء") }
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(modifier = Modifier.padding(paddingValues).fillMaxSize()) {
            when (selectedTab) {
                0 -> StaffCatalogScreen(
                    staffList = staffList,
                    onBookClick = { selectedStaffForBooking = it },
                    onSendToAdminChat = { member ->
                        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                        val newMsg = ChatMessage(
                            senderIsAdmin = false,
                            text = "مرحباً إدارة مركز الشيخة، أرغب بالاستفسار أو الحجز مع العضو: ${member.name}",
                            timestamp = time,
                            attachedStaff = member
                        )
                        messages = messages + newMsg
                        storage.saveChatMessages(messages)
                        selectedTab = 2
                    }
                )
                1 -> BookingsScreen(
                    bookings = bookings,
                    onDeleteBooking = { id ->
                        bookings = bookings.filterNot { it.id == id }
                        storage.saveBookings(bookings)
                    }
                )
                2 -> AdminChatScreen(
                    messages = messages,
                    staffList = staffList,
                    isAdminMode = isAdminMode,
                    onSendMessage = { text, attached ->
                        val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                        val newMsg = ChatMessage(
                            senderIsAdmin = isAdminMode,
                            text = text,
                            timestamp = time,
                            attachedStaff = attached
                        )
                        messages = messages + newMsg
                        storage.saveChatMessages(messages)
                    }
                )
                3 -> AdminStaffManagementScreen(
                    staffList = staffList,
                    onAddNew = {
                        editingStaff = null
                        showAddEditDialog = true
                    },
                    onEdit = {
                        editingStaff = it
                        showAddEditDialog = true
                    },
                    onDelete = { id ->
                        staffList = staffList.filterNot { it.id == id }
                        storage.saveStaffList(staffList)
                    }
                )
            }
        }
    }

    selectedStaffForBooking?.let { staff ->
        BookingDialog(
            staff = staff,
            onDismiss = { selectedStaffForBooking = null },
            onConfirmBooking = { booking ->
                bookings = listOf(booking) + bookings
                storage.saveBookings(bookings)
                val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                val chatNotification = ChatMessage(
                    senderIsAdmin = false,
                    text = "طلب حجز جديد (${booking.bookingType.labelAr}) لمدة ${booking.hours} ساعة - المجموع: ${formatIqd(booking.totalPriceIqd)}",
                    timestamp = time,
                    attachedStaff = staff
                )
                messages = messages + chatNotification
                storage.saveChatMessages(messages)
                selectedStaffForBooking = null
                selectedTab = 2
            }
        )
    }

    if (showAddEditDialog) {
        StaffEditorDialog(
            existingStaff = editingStaff,
            onDismiss = { showAddEditDialog = false },
            onSave = { savedMember ->
                staffList = if (editingStaff == null) {
                    listOf(savedMember) + staffList
                } else {
                    staffList.map { if (it.id == savedMember.id) savedMember else it }
                }
                storage.saveStaffList(staffList)
                showAddEditDialog = false
            }
        )
    }
}

@Composable
fun StaffCatalogScreen(
    staffList: List<StaffMember>,
    onBookClick: (StaffMember) -> Unit,
    onSendToAdminChat: (StaffMember) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(staffList) { member ->
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, RoyalGold.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(member.name, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = RoyalGold)
                        Surface(
                            color = if (member.hasPrivatePlace) Color(0xFF1B5E20) else Color(0xFF6D4C41),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = if (member.hasPrivatePlace) "يتوفر مكان خاص" else "لا يتوفر مكان (زيارة)",
                                color = Color.White,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    if (member.bio.isNotBlank()) {
                        Text(member.bio, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f))
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    if (member.photos.isNotEmpty()) {
                        Text("معرض الصور (${member.photos.size}/10):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(member.photos) { uri ->
                                AsyncImage(
                                    model = uri,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.size(90.dp).clip(RoundedCornerShape(10.dp))
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("سعر الساعة", fontSize = 11.sp, color = Color.Gray)
                            Text(formatIqd(member.hourlyRateIqd), fontWeight = FontWeight.Bold, color = RoyalGold)
                        }
                        Column {
                            Text("سعر الليلة الكاملة", fontSize = 11.sp, color = Color.Gray)
                            Text(formatIqd(member.fullNightRateIqd), fontWeight = FontWeight.Bold, color = RoyalGold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { onBookClick(member) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = RoyalGold, contentColor = Color.Black)
                        ) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("حجز الآن", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { onSendToAdminChat(member) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("إرسال للإدارة")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminStaffManagementScreen(
    staffList: List<StaffMember>,
    onAddNew: () -> Unit,
    onEdit: (StaffMember) -> Unit,
    onDelete: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Button(
            onClick = onAddNew,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = RoyalGold, contentColor = Color.Black),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.PersonAdd, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("إضافة عضو جديد للكادر (حتى 10 صور)", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(staffList) { member ->
                Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(14.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(member.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                if (member.hasPrivatePlace) "يتوفر مكان خاص" else "لا يتوفر مكان (زيارة)",
                                fontSize = 12.sp,
                                color = RoyalGold
                            )
                            Text("الصور المرفوعة: ${member.photos.size} / 10", fontSize = 12.sp, color = Color.Gray)
                        }
                        Row {
                            IconButton(onClick = { onEdit(member) }) {
                                Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = RoyalGold)
                            }
                            IconButton(onClick = { onDelete(member.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StaffEditorDialog(
    existingStaff: StaffMember?,
    onDismiss: () -> Unit,
    onSave: (StaffMember) -> Unit
) {
    var name by remember { mutableStateOf(existingStaff?.name ?: "") }
    var hasPrivatePlace by remember { mutableStateOf(existingStaff?.hasPrivatePlace ?: true) }
    var hourlyRate by remember { mutableStateOf(existingStaff?.hourlyRateIqd?.toString() ?: "75000") }
    var nightRate by remember { mutableStateOf(existingStaff?.fullNightRateIqd?.toString() ?: "350000") }
    var bio by remember { mutableStateOf(existingStaff?.bio ?: "") }
    var photos by remember { mutableStateOf(existingStaff?.photos ?: emptyList()) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        val combined = (photos + uris.map { it.toString() }).take(10)
        photos = combined
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existingStaff == null) "إضافة عضو جديد" else "تعديل بيانات العضو", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("اسم العضو") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("هل يتوفر مكان خاص؟")
                        Switch(checked = hasPrivatePlace, onCheckedChange = { hasPrivatePlace = it })
                    }
                }
                item {
                    OutlinedTextField(
                        value = hourlyRate,
                        onValueChange = { hourlyRate = it.filter { c -> c.isDigit() } },
                        label = { Text("سعر الساعة (د.ع)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = nightRate,
                        onValueChange = { nightRate = it.filter { c -> c.isDigit() } },
                        label = { Text("سعر الليلة الكاملة (د.ع)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = { Text("ملاحظات إضافية") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    Button(
                        onClick = { imagePicker.launch("image/*") },
                        enabled = photos.size < 10,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("اختيار صور من الجهاز (${photos.size}/10)")
                    }
                }
                if (photos.isNotEmpty()) {
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(photos) { uri ->
                                Box {
                                    AsyncImage(
                                        model = uri,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.size(64.dp).clip(RoundedCornerShape(8.dp))
                                    )
                                    IconButton(
                                        onClick = { photos = photos.filterNot { it == uri } },
                                        modifier = Modifier.size(20.dp).align(Alignment.TopEnd).background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(
                            StaffMember(
                                id = existingStaff?.id ?: UUID.randomUUID().toString(),
                                name = name,
                                hasPrivatePlace = hasPrivatePlace,
                                hourlyRateIqd = hourlyRate.toLongOrNull() ?: 75000L,
                                fullNightRateIqd = nightRate.toLongOrNull() ?: 350000L,
                                bio = bio,
                                photos = photos
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalGold, contentColor = Color.Black)
            ) {
                Text("حفظ", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun BookingDialog(
    staff: StaffMember,
    onDismiss: () -> Unit,
    onConfirmBooking: (BookingRequest) -> Unit
) {
    var bookingType by remember { mutableStateOf(BookingType.HOURLY) }
    var hours by remember { mutableIntStateOf(2) }
    var date by remember { mutableStateOf("اليوم") }
    var time by remember { mutableStateOf("08:00 مساءً") }
    var notes by remember { mutableStateOf("") }

    val total = if (bookingType == BookingType.HOURLY) {
        staff.hourlyRateIqd * hours
    } else {
        staff.fullNightRateIqd
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("حجز موعد: ${staff.name}", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    if (staff.hasPrivatePlace) "المكان: يتوفر مكان خاص" else "المكان: لا يتوفر مكان (زيارة)",
                    color = RoyalGold,
                    fontWeight = FontWeight.SemiBold
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = bookingType == BookingType.HOURLY,
                        onClick = { bookingType = BookingType.HOURLY },
                        label = { Text("بالساعات") }
                    )
                    FilterChip(
                        selected = bookingType == BookingType.FULL_NIGHT,
                        onClick = { bookingType = BookingType.FULL_NIGHT },
                        label = { Text("ليلة كاملة") }
                    )
                }
                if (bookingType == BookingType.HOURLY) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("عدد الساعات:")
                        IconButton(onClick = { if (hours > 1) hours-- }) { Icon(Icons.Default.Remove, contentDescription = null) }
                        Text("$hours", fontWeight = FontWeight.Bold)
                        IconButton(onClick = { if (hours < 12) hours++ }) { Icon(Icons.Default.Add, contentDescription = null) }
                    }
                }
                OutlinedTextField(value = date, onValueChange = { date = it }, label = { Text("التاريخ") })
                OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("الوقت") })
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("ملاحظات") })
                Text("الإجمالي: ${formatIqd(total)}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = RoyalGold)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirmBooking(
                        BookingRequest(
                            staffId = staff.id,
                            staffName = staff.name,
                            hasPrivatePlace = staff.hasPrivatePlace,
                            bookingType = bookingType,
                            hours = if (bookingType == BookingType.HOURLY) hours else 12,
                            date = date,
                            time = time,
                            totalPriceIqd = total,
                            clientNotes = notes
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = RoyalGold, contentColor = Color.Black)
            ) {
                Text("تأكيد وإرسال للإدارة", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

@Composable
fun BookingsScreen(
    bookings: List<BookingRequest>,
    onDeleteBooking: (String) -> Unit
) {
    if (bookings.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("لا توجد حجوزات مسجلة حالياً", color = Color.Gray)
        }
    } else {
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(bookings) { b ->
                Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.padding(14.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(b.staffName, fontWeight = FontWeight.Bold, color = RoyalGold)
                            Text("${b.bookingType.labelAr} (${b.hours} ساعة) - ${b.date} | ${b.time}", fontSize = 13.sp)
                            Text(if (b.hasPrivatePlace) "يتوفر مكان خاص" else "لا يتوفر مكان (زيارة)", fontSize = 12.sp)
                            Text("المبلغ: ${formatIqd(b.totalPriceIqd)}", fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { onDeleteBooking(b.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = null, tint = Color.Red)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminChatScreen(
    messages: List<ChatMessage>,
    staffList: List<StaffMember>,
    isAdminMode: Boolean,
    onSendMessage: (String, StaffMember?) -> Unit
) {
    var inputText by remember { mutableStateOf("") }
    var showStaffPicker by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Surface(color = RoyalGold.copy(alpha = 0.15f), modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "دردشة مباشرة مع إدارة مركز الشيخة (الخصوصية تامة)",
                modifier = Modifier.padding(10.dp),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = RoyalGold
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                val align = if (msg.senderIsAdmin) Alignment.Start else Alignment.End
                Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = align) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (msg.senderIsAdmin) MaterialTheme.colorScheme.surface else RoyalGold.copy(alpha = 0.25f),
                        modifier = Modifier.widthIn(max = 290.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                if (msg.senderIsAdmin) "إدارة مركز الشيخة" else "العميل",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = RoyalGold
                            )
                            msg.attachedStaff?.let { staff ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color.Black.copy(alpha = 0.25f),
                                    modifier = Modifier.padding(vertical = 6.dp).fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(8.dp)) {
                                        Text("ملف العضو: ${staff.name}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text(
                                            if (staff.hasPrivatePlace) "يتوفر مكان خاص" else "لا يتوفر مكان (زيارة)",
                                            fontSize = 11.sp,
                                            color = RoyalGold
                                        )
                                        Text("الساعة: ${formatIqd(staff.hourlyRateIqd)} | الليلة: ${formatIqd(staff.fullNightRateIqd)}", fontSize = 11.sp)
                                    }
                                }
                            }
                            Text(msg.text, fontSize = 14.sp)
                            Text(msg.timestamp, fontSize = 10.sp, color = Color.Gray, modifier = Modifier.align(Alignment.End))
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier.padding(10.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(onClick = { showStaffPicker = true }) {
                Icon(Icons.Default.AttachFile, contentDescription = "إرفاق ملف عضو", tint = RoyalGold)
            }
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("اكتب رسالتك للإدارة...") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp)
            )
            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        onSendMessage(inputText, null)
                        inputText = ""
                    }
                }
            ) {
                Icon(Icons.Default.Send, contentDescription = "إرسال", tint = RoyalGold)
            }
        }
    }

    if (showStaffPicker) {
        AlertDialog(
            onDismissRequest = { showStaffPicker = false },
            title = { Text("إرسال ملف عضو للإدارة") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(staffList) { member ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable {
                                onSendMessage("أرغب باختيار هذا العضو:", member)
                                showStaffPicker = false
                            }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(member.name, fontWeight = FontWeight.Bold)
                                Text(
                                    if (member.hasPrivatePlace) "يتوفر مكان خاص" else "لا يتوفر مكان (زيارة)",
                                    fontSize = 12.sp,
                                    color = RoyalGold
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showStaffPicker = false }) { Text("إغلاق") }
            }
        )
    }
}
