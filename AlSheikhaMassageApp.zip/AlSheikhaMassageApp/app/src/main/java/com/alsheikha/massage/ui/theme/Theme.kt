package com.alsheikha.massage.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val RoyalGold = Color(0xFFD4AF37)
val RoyalGoldLight = Color(0xFFF3E5AB)
val DarkObsidian = Color(0xFF0E0E12)
val DarkCard = Color(0xFF1A1A22)
val LightCream = Color(0xFFFAF8F5)
val LightCard = Color(0xFFFFFFFF)

private val DarkColors = darkColorScheme(
    primary = RoyalGold,
    onPrimary = Color.Black,
    secondary = RoyalGoldLight,
    background = DarkObsidian,
    surface = DarkCard,
    onBackground = Color.White,
    onSurface = Color.White
)

private val LightColors = lightColorScheme(
    primary = RoyalGold,
    onPrimary = Color.Black,
    secondary = Color(0xFF8C6D1F),
    background = LightCream,
    surface = LightCard,
    onBackground = Color(0xFF1C1B1F),
    onSurface = Color(0xFF1C1B1F)
)

@Composable
fun AlSheikhaTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        content = content
    )
}
