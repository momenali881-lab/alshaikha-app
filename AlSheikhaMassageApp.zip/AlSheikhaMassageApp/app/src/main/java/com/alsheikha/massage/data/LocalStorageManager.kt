package com.alsheikha.massage.data

import android.content.Context
import com.alsheikha.massage.model.BookingRequest
import com.alsheikha.massage.model.ChatMessage
import com.alsheikha.massage.model.StaffMember
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class LocalStorageManager(context: Context) {
    private val prefs = context.getSharedPreferences("al_sheikha_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun saveStaffList(list: List<StaffMember>) {
        prefs.edit().putString("staff_list", gson.toJson(list)).apply()
    }

    fun getStaffList(): List<StaffMember> {
        val json = prefs.getString("staff_list", null) ?: return defaultStaffList()
        val type = object : TypeToken<List<StaffMember>>() {}.type
        return gson.fromJson(json, type)
    }

    fun saveBookings(list: List<BookingRequest>) {
        prefs.edit().putString("bookings_list", gson.toJson(list)).apply()
    }

    fun getBookings(): List<BookingRequest> {
        val json = prefs.getString("bookings_list", null) ?: return emptyList()
        val type = object : TypeToken<List<BookingRequest>>() {}.type
        return gson.fromJson(json, type)
    }

    fun saveChatMessages(list: List<ChatMessage>) {
        prefs.edit().putString("chat_messages", gson.toJson(list)).apply()
    }

    fun getChatMessages(): List<ChatMessage> {
        val json = prefs.getString("chat_messages", null) ?: return listOf(
            ChatMessage(
                senderIsAdmin = true,
                text = "أهلاً بك في مركز الشيخة. هذه الدردشة المباشرة مع الإدارة، يمكنك اختيار أي عضو من الكادر وإرسال ملفه هنا لتأكيد الحجز.",
                timestamp = "الآن"
            )
        )
        val type = object : TypeToken<List<ChatMessage>>() {}.type
        return gson.fromJson(json, type)
    }

    fun isDarkMode(): Boolean = prefs.getBoolean("dark_mode", true)
    fun setDarkMode(enabled: Boolean) = prefs.edit().putBoolean("dark_mode", enabled).apply()

    private fun defaultStaffList(): List<StaffMember> = listOf(
        StaffMember(
            name = "ليلى الحسيني",
            hasPrivatePlace = true,
            isAvailable = true,
            hourlyRateIqd = 75000,
            fullNightRateIqd = 350000,
            bio = "خبرة متميزة في جلسات الاسترخاء الملكية والعناية المتكاملة.",
            photos = emptyList()
        ),
        StaffMember(
            name = "نور الكاظمي",
            hasPrivatePlace = false,
            isAvailable = true,
            hourlyRateIqd = 65000,
            fullNightRateIqd = 300000,
            bio = "جلسات احترافية مريحة مع الالتزام التام بالخصوصية والمواعيد.",
            photos = emptyList()
        ),
        StaffMember(
            name = "سارة المنصور",
            hasPrivatePlace = true,
            isAvailable = true,
            hourlyRateIqd = 85000,
            fullNightRateIqd = 400000,
            bio = "خدمة راقية ومكان مجهز بالكامل بأعلى معايير الفخامة والهدوء.",
            photos = emptyList()
        )
    )
}
