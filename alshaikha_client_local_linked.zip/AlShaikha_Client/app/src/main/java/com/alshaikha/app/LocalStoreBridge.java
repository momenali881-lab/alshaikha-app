package com.alshaikha.app;
import android.content.Context;
import android.content.ContentResolver;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;

public class LocalStoreBridge {
    private final Context context;
    private final Uri uri = Uri.parse("content://com.alshaikha.admin.localdata");
    public LocalStoreBridge(Context c) { context = c.getApplicationContext(); }
    @JavascriptInterface public String read() {
        try { Bundle b=context.getContentResolver().call(uri,"read",null,null); return b==null?"":b.getString("data",""); }
        catch(Exception e) { return ""; }
    }
    @JavascriptInterface public boolean write(String data) {
        try { Bundle b=new Bundle(); b.putString("data",data); Bundle r=context.getContentResolver().call(uri,"write",null,b); return r!=null && r.getBoolean("ok",false); }
        catch(Exception e) { return false; }
    }
}
