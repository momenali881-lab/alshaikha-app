# مشروع الشيخة – نسخة Android

هذا مشروع Android Studio يحوّل واجهة `index.html` الأصلية إلى تطبيق Android باستخدام WebView.

## بناء APK
1. فك ضغط الملف.
2. افتح مجلد `AlSheikhaAdmin_AndroidStudio` في Android Studio.
3. انتظر مزامنة Gradle وتنزيل أدوات Android المطلوبة.
4. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. ستجد الملف غالباً في `app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظات
- أبقيت واجهة HTML/JavaScript الأصلية كما هي.
- بيانات اللوحة التي تحفظها الواجهة في `localStorage` تبقى محلياً على الجهاز.
- بعض موارد الواجهة الخارجية مثل خطوط Google وأيقونات Font Awesome والصور تحتاج اتصال إنترنت.
- هذه الحزمة مشروع مصدر قابل للبناء، وليست APK موقّعاً جاهزاً للتثبيت.
